<?php 

  namespace MobikwikPG\Magento\Controller\Checkout;

  class Redirect extends \Magento\Framework\App\Action\Action {
    
    protected $_scopeConfig;
    protected $_storeManager;
    protected $_checkoutSession;
    protected $_layout;
    protected $_pay;
    


    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    \Magento\Store\Model\StoreManagerInterface $storeManager,
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Psr\Log\LoggerInterface $logger,
    \Magento\Framework\View\LayoutInterface $layout,
     \MobikwikPG\Magento\Model\Transact $pay
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_checkoutSession = $checkoutSession;
        $this->_layout = $layout;
        $this->_logger = $logger;
        $this->_pay = $pay;
        parent::__construct($context);
    }
    public function execute() {
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
      $session = $objectManager->get('\Magento\Checkout\Model\Session');
      $session->setZaakpayQuoteId($session->getQuoteId());
      $this->getResponse()->setBody($this->_pay->getPostForm());
      $session->unsQuoteId();
      $session->unsRedirectUrl();
    }

  }
