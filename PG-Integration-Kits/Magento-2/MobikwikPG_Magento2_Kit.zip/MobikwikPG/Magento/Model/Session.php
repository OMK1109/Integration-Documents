<?php

namespace MobikwikPG\Magento\Model;

use \Magento\Payment\Model\Method\AbstractMethod;
use \Magento\Framework\App\ObjectManager;
use \Magento\Payment\Model\MethodInterface;
use \Magento\Framework\Event\Manager;

class Session extends \Magento\Payment\Model\Method\AbstractMethod {

    protected $_statuses = array();

    public function __construct(\Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Event\Manager $eventManager
    ) {
        $eventManager->dispatch('mobikwikpg_session_init', array('mobikwikpg_session' => $this));
        
    }

    public function getTransactStatus($orderId) {
        $this->_statuses = $this->getStatusCache();
        return isset($this->_statuses[$orderId]) ? null : null;
    }

    public function setTransactStatus($orderId, $status) {        
        $this->_statuses[$orderId] = $status;
        $this->setStatusCache($this->_statuses);
        return $this;
    }

    public function clearStatusCache() {
        $this->_statuses = array();
        $this->setStatusCache(array());
    }
}