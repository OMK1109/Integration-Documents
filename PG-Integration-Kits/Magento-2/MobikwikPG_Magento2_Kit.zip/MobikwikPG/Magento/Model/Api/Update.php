<?php 

namespace MobikwikPG\Magento\Model\Api;

use \Magento\Payment\Model\Method\AbstractMethod;
use \Magento\Framework\App\ObjectManager;

class Update extends \Magento\Framework\DataObject 
{

    const UPDATE_ENDPOINT = 'https://api.zaakpay.com/updatetransaction';
	const CHECK_ENDPOINT = 'https://api.zaakpay.com/checktransaction';

    const STATUS_CANCELLED = '8';

    const STATUS_REFUNDED = '14';

    const STATUS_SETTLED = '7';

    const CANCELLED_RESP_CODES = array(226, 198);
    
    public function send($orderId, $updateDesired, $updateReason)
    {  
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request_new = $objectManager->create('RequestAPI');
        $request_new->setConfig($this->_scopeConfig->getValue('payment/mobikwik_gateway'))
            ->setUrl(self::CHECK_ENDPOINT)
            ->addParam('orderId', $orderId)
            ->send();
        $response = $request_new->getResponseCode();
        //***********************************************************//
		if($response == 233)
		{
		$updateDesired = 14;
		}
		else
		{
		$updateDesired = 8;
		}
		
		//***********************************************************//
	 
        // unset the statuscache 
        $session = $objectManager->get('MobikwikPG\Magento\Model\Session');
        $session->clearStatusCache();

    }
}
