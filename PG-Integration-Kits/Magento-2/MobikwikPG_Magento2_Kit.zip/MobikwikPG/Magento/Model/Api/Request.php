<?php


namespace MobikwikPG\Magento\Model\Api;

use \Magento\Payment\Model\Method\AbstractMethod;
use \Magento\Framework\App\ObjectManager;
use \MobikwikPG\Magento\Helper\Checksum as Checksum;


class Request extends \Magento\Framework\DataObject 
{

    private $_params = array();

    private $_sendFlag = false;

    protected $_scopeConfig;
    
    protected $_exception;

    
    protected $_transactionRepository;


    protected $_transactionBuilder;

    
    protected $_urlBuilder;

    protected $_orderFactory;


    protected $_storeManager;

    public function __construct(
      \Magento\Framework\UrlInterface $urlBuilder,
      \Magento\Framework\Exception\LocalizedExceptionFactory $exception,
      \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
      \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder,
      \Magento\Sales\Model\OrderFactory $orderFactory,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Model\Context $context,
      \Magento\Framework\Registry $registry,
      \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
      \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
      \Magento\Payment\Helper\Data $paymentData,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Payment\Model\Method\Logger $logger,
       
        
      array $data = []
    ) {
      $this->_urlBuilder = $urlBuilder;
      $this->_exception = $exception;
      $this->_transactionRepository = $transactionRepository;
      $this->_transactionBuilder = $transactionBuilder;
      $this->_orderFactory = $orderFactory;
      $this->_storeManager = $storeManager;

      parent::__construct(
          $data
      );
    }

    public function addParam($key, $value) 
    {
        $this->_params[$key] = $value;
        return $this;
    }



    /**
     * Method to send the request to the zaakpay api
     * identified by the endpoint (url)
     */
    public function send() 
    {
        $config = $this->_scopeConfig->getValue('payment/mobikwik_gateway');
        $this->_params = array_merge($this->_params, array(
            'merchantIdentifier' => $this->_scopeConfig->getValue('payment/mobikwik_gateway/merchant_identifier'),
            'mode' => $this->_scopeConfig->getValue('payment/mobikwik_gateway/sandbox_mode') ? '0' : '0',
        ));

        $fields = $this->_params;

        $all = Checksum::getAllParamsCheckandUpdate($fields);

        $checksum = Checksum::calculateChecksum($this->_scopeConfig->getValue('payment/mobikwik_gateway/secret_key'), $all);
        $fields['checksum'] = $checksum;
        $query_string = http_build_query($fields);

        
        $ch = curl_init();
        
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $this->getUrl());
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        
        //execute post
        $result = curl_exec($ch);

        // incase of an error, log it
        if(curl_errno($ch)) {
            $this->_logger->debug('Curl error: ' . curl_error($ch));
            throw new \Magento\Framework\Exception\LocalizedException(__('Request not completed because of an error connecting to zaakpay server for transaction update. See exception logs'));
        } else {
            //close connection
            curl_close($ch);
            $this->_processResponse($result);
            $this->_sentFlag = true;
        }
    }

    protected function _processResponse($response) 
    {
        $this->setResponse($response);
        $responseObj = simplexml_load_string($response);
        $this->setResponseObj($responseObj);
        $this->setResponseCode((int)$responseObj->response_element->responsecode);
        $this->setResponseDescription((string) $responseObj->response_element->description);
    }

    public function isResponseCode($code) 
    {
        return $this->getResponseCode() == $code;
    }
}
