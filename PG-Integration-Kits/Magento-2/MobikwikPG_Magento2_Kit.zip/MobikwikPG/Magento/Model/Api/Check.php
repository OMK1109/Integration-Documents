<?php

namespace MobikwikPG\Magento\Model\Api;

use \Magento\Payment\Model\Method\AbstractMethod;
use \Magento\Framework\App\ObjectManager;
use \MobikwikPG\Magento\Model\Api\RequestApi as RequestAPI;

class Check extends \Magento\Framework\DataObject 
{

    const CHECK_ENDPOINT = 'https://api.zaakpay.com/checktransaction';

    
    protected $_exception;

    
    protected $_transactionRepository;


    protected $_transactionBuilder;

    
    protected $_urlBuilder;

    protected $_orderFactory;


    protected $_storeManager;

    public function __construct(
      \Magento\Framework\UrlInterface $urlBuilder,
      \Magento\Framework\Exception\LocalizedExceptionFactory $exception,
      \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
      \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder,
      \Magento\Sales\Model\OrderFactory $orderFactory,
      \Magento\Store\Model\StoreManagerInterface $storeManager,
      \Magento\Framework\Model\Context $context,
      \Magento\Framework\Registry $registry,
      \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
      \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
      \Magento\Payment\Helper\Data $paymentData,
      \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
      \Magento\Payment\Model\Method\Logger $logger,
       
        
      array $data = []
    ) {
      $this->_urlBuilder = $urlBuilder;
      $this->_exception = $exception;
      $this->_transactionRepository = $transactionRepository;
      $this->_transactionBuilder = $transactionBuilder;
      $this->_orderFactory = $orderFactory;
      $this->_storeManager = $storeManager;

      parent::__construct(
          $data
      );
    }
    
    public function check($orderId)
    {   $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $request = $objectManager->create('RequestAPI');
        $request->setValue($this->_scopeConfig->getValue('payment/mobikwik_gateway'))
            ->setUrl(self::CHECK_ENDPOINT)
            ->addParam('orderId', $orderId)
            ->send();
        $this->setResponseCode($request->getResponseCode());
        $this->setResponseDescription($request->getResponseDescription());
    }
}