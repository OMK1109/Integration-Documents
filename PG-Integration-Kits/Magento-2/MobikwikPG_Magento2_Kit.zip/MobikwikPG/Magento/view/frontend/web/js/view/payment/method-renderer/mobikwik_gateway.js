define(
    [
        'Magento_Checkout/js/view/payment/default',
        'mage/url'
    ],
    function (Component,url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'MobikwikPG_Magento/payment/form',
            },



            
            redirectAfterPlaceOrder: false,



            afterPlaceOrder: function() {
                window.location.replace(url.build('mobikwikpg/checkout/redirect'));
            }
        });
    }
);