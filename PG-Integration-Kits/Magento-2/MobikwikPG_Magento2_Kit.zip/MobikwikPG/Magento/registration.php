<?php
	\Magento\Framework\Component\ComponentRegistrar::register(
	    \Magento\Framework\Component\ComponentRegistrar::MODULE,
	    'MobikwikPG_Magento',
	    __DIR__
);
