class PaymentsController < ApplicationController
  
  # GET /merchant_test  
  def merchant_test
    render :layout => false
  end
  
  # POST /post_to_zaakpay
  def post_to_zaakpay
    zr = Zaakpay::Request.new(params) 
    @zaakpay_data = zr.all_params   
    render :layout => false    
  end
  
  # POST /z_response
  def z_response
    zr = Zaakpay::Response.new(request.raw_post)  
    @checksum_check = zr.valid?
    @zaakpay_post = zr.all_params
    render :layout => false
  end

  # GET /check_test
  def check_test
    render :layout => false 
  end

  # POST /checktxn
  def check_txn
    zr = Zaakpay::CheckandUpdateRequest.new(params) 
    @zaakpay_check_data = zr.all_params   
    render :layout => false
  end

  # GET /update_test
  def update_test
    render :layout => false 
  end

  # POST /updatetxn
  def update_txn
    zr = Zaakpay::CheckandUpdateRequest.new(params) 
    @zaakpay_update_data = zr.all_params   
    render :layout => false
  end
  
end