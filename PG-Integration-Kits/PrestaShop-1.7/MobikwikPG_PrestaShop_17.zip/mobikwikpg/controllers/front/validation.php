<?php
/*
* 2007-2015 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2015 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class MobikwikpgValidationModuleFrontController extends ModuleFrontController
{
    /**
     * @see FrontController::postProcess()
     */

    public $warning = '';
    public $message = '';
    public function initContent()
    {  
      parent::initContent();
  
      $this->context->smarty->assign(array(
          'warning' => $this->warning,
          'message' => $this->message
          ));         
      
      $this->setTemplate('module:mobikwikpg/views/templates/front/payment_return.tpl');  
        
        
    }
    public function postProcess()
    {
      $cart = $this->context->cart;
      if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active) {
          Tools::redirect('index.php?controller=order&step=1');
      }

      // Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
      $authorized = false;
      foreach (Module::getPaymentModules() as $module) {
          if ($module['name'] == 'mobikwikpg') {
              $authorized = true;
              break;
          }
      }

      if (!$authorized) {
          die($this->module->l('This payment method is not available.', 'validation'));
      }


      $customer = new Customer($cart->id_customer);
      if (!Validate::isLoadedObject($customer))
          Tools::redirect('index.php?controller=order&step=1');


      $postdata = $_REQUEST;

      $currency = $this->context->currency;
      $merchant_identifier= Configuration::get('MERCHANT_IDENTIFIER');
      $secret_key= Configuration::get('SECRET_KEY');
      $cart_id = $cart->id;
      $order_id = $postdata['orderId'];
      $received_checksum = $postdata['checksum'];

      $all = '';
      $checksumsequence= array("amount","bank","bankid","cardId",
        "cardScheme","cardToken","cardhashid","doRedirect","orderId",
        "paymentMethod","paymentMode","responseCode","responseDescription",
        "productDescription","product1Description","product2Description",
        "product3Description","product4Description","pgTransId","pgTransTime");
      foreach($checksumsequence as $seqvalue) {
        if(array_key_exists($seqvalue, $postdata))  {
      
          $all .= $seqvalue;
          $all .="=";
          $all .= $postdata[$seqvalue];
          $all .= "&";
          }
        }
  
  
      $calculated_checksum = $this->calculateChecksum($secret_key, $all);

      if (isset($postdata['responseCode']) && $postdata['responseCode'] == 100) {
    
        $status = Configuration::get('MOBIKWIKPG_ID_ORDER_FAILED');
        $responseMsg = "Thank you for shopping with us. However, the transaction has been declined.";
        
        if($received_checksum==$calculated_checksum){
          $status = Configuration::get('MOBIKWIKPG_ID_ORDER_SUCCESS');
          $responseMsg = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
        } else {
          //tampered
          $status = Configuration::get('MOBIKWIKPG_ID_ORDER_FAILED');
          $responseMsg = "Thank you for shopping with us. However, the payment failed";
          $this->message = "Payment gateway response is not received in proper format. Could be an attempt to tamper payment.";
        }
      }
      else {
        $status = Configuration::get('MOBIKWIKPG_ID_ORDER_FAILED');
        $responseMsg = "Thank you for shopping with us. However, the payment has been cancelled or declined.";
        $this->message = "Payment gateway responded - ". $postdata['responseDescription'];
      }

      $amount = $postdata['amount']/100;
      PrestaShopLogger::addLog("MobikwikPG: Created Order for Orderid-".$order_id,1, null, 'MobikwikPG', (int)$cart_id, true);
      $this->module->validateOrder((int)$cart_id,  $status, (float)$amount, "MobikwikPG", null, null, null, false, $customer->secure_key);

    
    if ($status == Configuration::get('MOBIKWIKPG_ID_ORDER_SUCCESS'))
    {     
      $order = new Order((int)$this->module->currentOrder);
      $payments = $order->getOrderPaymentCollection();
      $payments[0]->transaction_id = $postdata['orderId'];
      $payments[0]->update();
      Tools::redirect('index.php?controller=order-confirmation&id_cart='.(int)$cart->id.'&id_module='.(int)$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
    }
    else
    {
      $this->warning= $responseMsg;      
    }

  }

  function calculateChecksum($secret_key, $all) {
    $hash = hash_hmac('sha256', $all , $secret_key);
    $checksum = $hash;
    return $checksum;
  }
}
