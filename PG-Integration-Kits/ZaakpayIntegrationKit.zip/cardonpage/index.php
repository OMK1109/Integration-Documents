<?php
require_once('Constants.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Zaakpay's dummy merchant site</title>
<script type="text/javascript" src="/javascripts/ga.js"></script>
 </head>
<script>

function autoPop(){
	document.getElementById("orderId").value= "ZPLive" + String(new Date().getTime());	//	Autopopulating orderId
	var today = new Date();
	var dateString = String(today.getFullYear()).concat("-").concat(String(today.getMonth()+1)).concat("-").concat(String(today.getDate()));
	document.getElementById("txnDate").value= dateString;
};

function submitForm(){
			var form = document.forms[0];
			form.action = "merchant_card_page.php";
			form.submit();
			}
</script>
<style type="text/css">
.center{ width:800px; margin:30px auto;}

.heading{ width:790px; float:left; background-color:#1c373f; -webkit-border-radius: 5px 5px 0 0; -moz-border-radius: 5px 5px 0 0; border-radius: 5px 5px 0 0; border:1px solid #000000;  border-bottom:none; padding:0 0 0 10px; }
.heading h2 {padding:10px 0 0 0;margin: 0;font:bold 30px Calibri, Arial, Helvetica, sans-serif;text-align:Center;color:#ffffff;}
.ecssing{width:790px;float:left;padding:15px 0 30px 10px;margin:0px 0 30px 0;background-color:#e9f0f2;filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f7fbfc', endColorstr='#e9f0f2'); /* for IE */background: -webkit-gradient(linear, left top, left bottom, from(#f7fbfc), to(#e9f0f2)); /* for webkit browsers */background: -moz-linear-gradient(top, #f7fbfc, #e9f0f2); /* for firefox 3.6+ */	-webkit-border-radius:0 0 5px 5px;-moz-border-radius:0 0 5px 5px;-o-border-radius:0 0 5px 5px;border-radius:0 0 5px 5px; border:1px solid #000000;}
.logoz{width:800px; float:left;}
.logoz-b{width:800px; float:left;}
.logoz-b-l{width:400px; float:left;font:bold italic 26px Arial, Helvetica, sans-serif !important;text-align:left;color:#000000; padding:0 0 0 120px;}
.logoz-b-r{width:175px; float:left;}
label {padding:15px 0px 5px 0; margin:0px;width:225px; float:left;font:normal 14px Arial, Helvetica, sans-serif !important;text-align:left;color:#000000;}
input {border:1px solid #848484; border-top:2px solid #848484;	background-color:#FFFFFF;padding:2px 2px; margin:0px 0 3px 0;width:200px;color:#000000;font:normal 12px Arial, Helvetica, sans-serif;text-align:left;	height:18px;}
 select {border:1px solid #848484; border-top:2px solid #848484;	background-color:#FFFFFF;padding:2px 1px 2px 2px; margin:0px 0 3px 0;width:204px;color:#000000;font:normal 12px Arial, Helvetica, sans-serif;text-align:left;	}
 .boxes {width:auto;margin:0;padding:5px 15px;text-align:center;	-webkit-border-radius: 7px;-moz-border-radius: 7px;-o-border-radius: 7px;-border-radius: 7px;text-decoration:none !important;font:bold 20px/22px Arial, Helvetica, sans-serif;color:#ffffff !important;background-color:#558a04; /* for non-css3 browsers */filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#83d801', endColorstr='#558a04'); /* for IE */background: -webkit-gradient(linear, left top, left bottom, from(#83d801), to(#558a04)); /* for webkit browsers */background: -moz-linear-gradient(top, #83d801, #558a04); /* for firefox 3.6+ */
	behavior: url(border-radius.htc);}
.boxes a {font:bold 20px/22px Arial, Helvetica, sans-serif;	text-align:center;color:#ffffff !important;	text-decoration:none !important;}
.boxes a:hover {text-decoration:none !important;}
</style>

<body onload="autoPop();">

<div class="center">
<div class="heading"><img src="/images/zaakpaylogobeta.gif" alt=""  align="left" />
<h2>Example Checkout Page</h2>
<p></p>
</div>
<div class="ecssing">
<form method="post">
<div class="logoz">
<div class="logoz-b">
<div class="logoz-b-l">Checkout</div>

</div>
</div><br clear="left" />


<table width="650px;">
<tr>
	<td colspan="2" align="center" valign="middle"></td>
	
</tr>

<input type="hidden" name="merchantIdentifier" value="<?php echo MID; ?>" />

<tr>	
	<td width="50%" align="right" valign="middle">Order Id</td>
	<td width="50%" align="center" valign="middle"><input type="text" id="orderId" name="orderId" /></td>
</tr>

<input type="hidden" name="mode" value="0" />
<input type="hidden" name="currency" value="INR" />
<tr>	
	<td width="50%" align="right" valign="middle">Amount</td>
	<td width="50%" align="center" valign="middle"><input type="text" id="amount" name="amount" value="1000"/></td>
</tr>


<input type="hidden" name="merchantIpAddress" value="127.0.0.1" />

<input type="hidden" name="txnDate" id="txnDate" />

<tr>
	<td colspan="2" width="100%" align="center" valign="middle">
		<div style="cursor:pointer; padding-top: 25px; padding-left: 300px;">
			<a class="boxes" onclick="javascript:submitForm()">Pay via zaakpay
			</a>
		</div>
	</td>	
</tr>


</table>

</form>
</div>
</div>

		
		
</body>
</html>