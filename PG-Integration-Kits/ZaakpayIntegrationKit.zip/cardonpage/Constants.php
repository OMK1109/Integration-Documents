<?php

define('MID','96d14f9d3413432091e57663d091201d');
define('SECRETKEY','7da3ebc83aed4daa9e7c11e8b711a9ee');

?>