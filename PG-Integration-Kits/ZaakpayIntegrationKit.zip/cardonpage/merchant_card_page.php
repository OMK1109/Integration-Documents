<?php

require_once('Constants.php');
require_once('lib/checksum.php');

$parameters = Array();
$parameters[] = 'merchantIdentifier' ;
$parameters[] = 'orderId';
$parameters[] = 'mode';
$parameters[] = 'currency';
$parameters[] = 'amount';
$parameters[] = 'merchantIpAddress';
$parameters[] = 'txnDate';

function getAllParams($parameters) {
		$all = '';
		foreach($_POST as $key => $value)	{
			if(in_array($key,$parameters)) {
				$all .= "'" . Checksum::sanitizedParam($value) . "'";
			}
		}
		return $all;
	}

$all = getAllParams($parameters);

$checksum = Checksum::calculateChecksum(SECRETKEY, $all);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Zaakpay's dummy merchant site</title>
  <link href="stylesheets/style-payment-page.css" rel="stylesheet" type="text/css" />
   <script type="text/javascript" src="https://api.zaakpay.com/zaakpay.js"></script>
    <script type="text/javascript" src="javascript/card_page.js?a=5"></script>
 </head>
<body >
 
<div class="center">
<div class="heading"><img src="images/zaakpaylogobeta.gif" alt=""  align="left" />
<h2>Example Checkout Page</h2>
<p></p>
</div>

</div> 

<div class="container">
       <div class="zaakmiddlecont" >
      <div class="zaakmaster">
       <form action="" method="post" id="creditForm0" autocomplete="off">
       <div class="ecssing">

<table width="650px;">
<tr>
	<td colspan="2" align="center" valign="middle"></td>
	
</tr>

<input type="hidden" name="merchantIdentifier" value="<?php echo $_POST['merchantIdentifier']; ?>" />

<tr style="display: none;">	
	<td width="50%" align="right" valign="middle">Order Id</td>
	<td width="50%" align="center" valign="middle"><input type="text" id="orderId" name="orderId" value="<?php echo $_POST['orderId']; ?>" /></td>
</tr>

<input type="hidden" name="returnUrl" value="http://localhost/cardonpage/test_merchant_output.php" />
<input type="hidden" name="showMobile" value="false" />

<tr style="display: none;">	
	<td width="50%" align="right" valign="middle">Buyer Email</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="buyerEmail" value="buyer@gmail.com"  /> </td>
</tr>

<tr style="display: none;">		
	<td width="50%" align="right" valign="middle">Buyer First Name</td>
	<td width="50%" align="center" valign="middle"><input type="text" name="buyerFirstName" value="first name" /> </td>
</tr>

<tr style="display: none;">	
	<td width="50%" align="right" valign="middle">Buyer Last Name</td>
	<td width="50%" align="center" valign="middle"> <input type="text" name="buyerLastName" value="last name" /></td>
</tr>


<input type="hidden" name="buyerAddress" value="26 nizamuddin" />

<input type="hidden" name="buyerCity" value="New Delhi" />

<input type="hidden" name="buyerState" value="Dilli" />

<input type="hidden" name="buyerCountry" value="India" />

<input type="hidden" name="buyerPincode" value="110075" />

<input type="hidden" name="buyerPhoneNumber"  />


<input type="hidden" name="txnType" value="1" />

<input type="hidden" name="zpPayOption" value="1" />


<input type="hidden" name="mode" value="<?php echo $_POST['mode']; ?>"  />

<input type="hidden" name="currency" value="<?php echo $_POST['currency']; ?>"  />

<input type="hidden" name="amount" value="<?php echo $_POST['amount']; ?>" />

<input type="hidden" name="merchantIpAddress" value="<?php echo $_POST['merchantIpAddress']; ?>"/>


<input type="hidden" name="purpose" value="1" />


<input type="hidden" name="productDescription" value="Zaakpay subscription fee" />


<input type="hidden" name="product1Description" />


<input type="hidden" name="product2Description" />


<input type="hidden" name="product3Description" />


<input type="hidden" name="shipToAddress" />


<input type="hidden" name="shipToCity" value="Ambala" />


<input type="hidden" name="shipToState" value="Karnataka" />


<input type="hidden" name="shipToCountry" />


<input type="hidden" name="shipToPincode" value="110075" />


<input type="hidden" name="shipToPhoneNumber" />


<input type="hidden" name="shipToFirstname" />


<input type="hidden" name="shipToLastname" />


<input type="hidden" name="txnDate" id="txnDate" value="<?php echo $_POST['txnDate']; ?>" />

<input type="hidden" name="checksum" id="checksum" value="<?php echo $checksum; ?>" />

 <input type="hidden" name="encryptedcvv" id="encryptedcvv"  />
 
   <input type="hidden"  name="debitorcredit" id="debitorcredit"  />
   
   <input type="hidden" name="encrypted_pan" id="encrypted_pan"  />
   
    <input type="hidden" name="card" id="card" />
    
    <input type="hidden" name="nameoncard" id="nameoncard" class="input" />
    <input type="hidden" id="pan" name="pan">
    <input type="hidden" name="encrypted_expiry_month" id="encrypted_expiry_month"  />
	<input type="hidden" name="encrypted_expiry_year" id="encrypted_expiry_year"  />



</table>

</div>
<div >Pay with your</div>
        <div id="credit" style="display:block;">
          <div class="zaakmiddlebottom" style="height:337px;">
           
       

              <div class="zaakpayboxe">
                
                <div class="zaakpaynav">
                  <ul>
                  
                    <li><a href="javascript:showCredit()" class="selected">Credit Card</a></li>
                    <li><a href="javascript:showDebit();">Debit Card</a></li>         
                    <li><a href="javascript:showNetBank();">Net Banking</a></li>
                   
                  </ul>
                </div>
                
                
                <div class="zaakpaysection" style="border-top:none">
                <!--  <h2>How to pay by Credit Card </h2>-->
                  <div class="zaakpay-1" style="display:none">
                    <div class="zaakpay-1-reuseable-l">1</div>
                    <div class="zaakpay-1-reuseable-2">Choose your <br/>
                      Credit Card</div>
                    <div class="zaakpay-1-reuseable-l">2</div>
                    <div class="zaakpay-1-reuseable-2 ">Enter your<br/>
                      card details</div>
                    <div class="zaakpay-1-reuseable-l">3</div>
                    <div class="zaakpay-1-reuseable-2">Verify card detials<br/>
                      on bank&rsquo;s website</div>
                    <div class="zaakpay-1-reuseable-l">4</div>
                    <div class="zaakpay-1-reuseable-2">Come back to see<br/>
                      transaction status</div>
                  </div>
                  
                  <div class="zaakpay-5">
                    <div class="zaakpay-5a"><!--<img src="/images/img/btn-red.jpg" alt="" />--></div>
                    <div class="zaakpay-5b">
                      <h2>Credit Card</h2>
                      <div class="zaakpay-5b-l"><input type="radio" name="card0" id="visa" value="VISA" /></div>
                      <div class="zaakpay-5b-r"><div class="logo-visa"></div></div>
                      <div class="zaakpay-5b-l"><input type="radio" name="card0" id="master" value="MC" /></div>
                      <div class="zaakpay-5b-r"><div class="logo-master"></div></div>
                                 
						<br clear="left" />
                      <div id="cardtype_error0" class="zaakeorr" style="padding:3px 0 2px 95px;" ></div>                    
                  </div>
				  </div>
                  
                  <div class="zaakpay-7">
                    <table bgcolor="#dddddd" width="580" border="0"  cellpadding="0" cellspacing="0">
                      <tr>
                        <td class="zaakpay-7-1">Card Number</td>
                        <td colspan="3"><label for="pan">
                        	
                          <input type="text" name="pan1" id="pan1" value="" maxlength="4" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan1','pan2')"/>
                          <input type="text" name="pan2" id="pan2" value="" maxlength="4" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan2','pan3')"/>
                          <input type="text" name="pan3" id="pan3" value="" maxlength="4" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan3','pan4')"/>
                          <input type="text" name="pan4" id="pan4" value="" maxlength="4" class="zaakzaw5 input" autocomplete="off" />
                          </label><br clear="left" />
                          <div class="formError zaakeorr1" id="pan_error0"></div></td>
                      </tr>
                   
                      <tr >
                        <td colspan="4"  height="5" bgcolor="#ffffff" ></td>
                      </tr>
                      <tr >
                        <td class="zaakpay-7-1">Expiration Date</td>
                        
                        <td>
                        	
                           <select class="select" name="expiry_month0" id="expiry_month0" style="width:50px;">
                            <option value="mm">mm</option>
                            <option value="1">01 </option>
                            <option value="2">02 </option>
                            <option value="3">03 </option>
                            <option value="4">04 </option>
                            <option value="5">05 </option>
                            <option value="6">06 </option>
                            <option value="7">07 </option>
                            <option value="8">08 </option>
                            <option value="9">09 </option>
                            <option value="10">10 </option>
                            <option value="11">11 </option>
                            <option value="12">12 </option>
                          </select>
                          /
                          <select class="select" name="expiry_year0" id="expiry_year0" style="width:50px;">
                            <option value="yy">yy</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>                            
                          </select><br clear="left" /><div class="formError zaakeorr1"  id="expiry_error0"> </div></td>
                          
                          
                          
                          <td class="zaakpay-7-2">CVV Code</td>
                        <td><label for="cvv0">
                            <input type="password" name="cvv0" id="cvv0" value="" maxlength="3" class="input"  style="width:40px;"/>
                           <!--  <input type="hidden" name="encryptedcvv" id="encryptedcvv" class="input"  /> -->
                          </label><a href="javascript:void(0);" onmouseover="alerts_show('alerts_pop5');" style="font:bold 12px Arial, Helvetica, sans-serif; padding:0px 0 0 10px; color:#000000;" onmouseout="alerts_hide('alerts_pop5')" title="">What is This</a><br clear="left" />
                          <div class="formError zaakeorr1"  id="cvv_error0"> </div></td>
                          
                          
                      </tr>
                      
                      <tr >
                        <td colspan="4"  height="5" bgcolor="#ffffff" ></td>
                      </tr>
                      <tr >
                        <td class="zaakpay-7-1">Name On Card</td>
                        <td><label for="nameoncard0">
                            <input type="text" name="nameoncard0" id="nameoncard0" value="Buyer Fn Ln" class="input" maxlength="100" autocomplete="off" onfocus="this.focus();"/>
                          </label><br clear="left" /><div class="formError zaakeorr1"  id="nameoncard_error0"> </div></td>
                        <!--<td colspan="2"  class="zaakpay-7-1" style="text-align:right"><a href="javascript:void(0);" onmouseover="alerts_show('alerts_pop5');" onmouseout="alerts_hide('alerts_pop5')" title="">What is This</a></td>-->
                      </tr>
                    
                      
                    </table>
                  </div>
                  
                  <div class="zaakpay-6">
                    <div class="zaakeorr" >
                      <div class="formError"> </div>
                    </div>
                  </div>
                  <div class="zaakpay-4">                  
                    <div class="zaakpay-4-l">
                     <div id="loader0"><img src="images/loader.gif" width="40" height="40" align="middle"/> &nbsp;Please Wait....</div>
                      <div class="zaakblue" id="paynow0">
                        <h2><a href="javascript:submitForm0();" >Pay Now</a></h2>
                      </div>
                    </div>
                    <div class="zaakpay-4-r"><div class="powerby"></div></div>
                  </div>
                </div>
              
              </div>
             
              <label for="expirydate">
                <input type="hidden" name="expirydate" id="expiry_date" />
              </label>
              
             </div>
            
                  
        </div>
      </div> 
    </div>
    
    <div class="zaakmiddlecont" >
      <div class="zaakmaster">
        
        <div id="debit" style="display:none;">
          <div class="zaakmiddlebottom" style="height:330px;">
           
            
<div class="ecssing">




<table width="650px;">
<tr>
	<td colspan="2" align="center" valign="middle"></td>
	
</tr>


</table>

</div>




              <div class="zaakpayboxe" id="selector">
               
                <div class="zaakpaynav">
                  <ul>
                 
                    <li><a href="javascript:showCredit()">Credit Card</a></li>
                    <li><a href="javascript:showDebit();" class="selected">Debit Card</a></li>
                 
                   
                  	<li><a href="javascript:showNetBank();" >Net Banking</a></li>
                  	
                  </ul>
                </div>
                
                
                <div class="zaakpaysection" style="border-top:none">
                 <!-- <h2>How to pay by Debit Card</h2>-->
                  <div class="zaakpay-1" style="display:none;">
                    <div class="zaakpay-1-reuseable-l">1</div>
                    <div class="zaakpay-1-reuseable-2">Choose your <br/>
                      Debit Card</div>
                    <div class="zaakpay-1-reuseable-l">2</div>
                    <div class="zaakpay-1-reuseable-2 ">Enter your<br/>
                      card details</div>
                    <div class="zaakpay-1-reuseable-l">3</div>
                    <div class="zaakpay-1-reuseable-2">Verify card detials<br/>
                      on bank&rsquo;s website</div>
                    <div class="zaakpay-1-reuseable-l">4</div>
                    <div class="zaakpay-1-reuseable-2">Come back to see<br/>
                      transaction status</div>
                  </div>
                  
                  <div class="zaakpay-2">
                    <div class="zaakpay-2-l" style="margin:13px 0 0 0;"><!--<img src="/images/img/btn-red.jpg" alt=""  align="top"/>--></div>
                    <br/>
                    <div class="zaakpay-2-r" >
                      <h2 >Debit Card</h2>
                      <label for="card1">
                        <select class="select" name="card1" style="width:165px;">
                          <option value="">Choose your Debit Card</option>
                          <option value="VISA">Visa Debit Card</option>
                          <option value="MC">Mastercard Debit Card</option>
                        </select>
                      </label>
                      <div id="cardtype_error1" class="zaakeorr" style="padding:3px 0 2px 87px;"></div>
                    </div>
                  </div>
                  
                  <div class="zaakpay-7">
                    <table bgcolor="#dddddd" width="580" border="0"  cellpadding="0" cellspacing="0">
                      <tr>
                        <td class="zaakpay-7-1">Card Number</td>
                        <td colspan="3"><label for="pan">
                         
                            <input type="hidden" autocomplete="off" maxlength="16" class="input" id="pan" name="pan">
           					<input type="text" name="pan5" id="pan5" maxlength="4" value="" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan5','pan6')"/>
           					<input type="text" name="pan6" id="pan6" maxlength="4" value="" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan6','pan7')"/>
           					<input type="text" name="pan7" id="pan7" maxlength="4" value="" class="zaakzaw5 input" autocomplete="off" onKeyUp="checkpan('pan7','pan8')"/>
           					<input type="text" name="pan8" id="pan8" maxlength="4" value="" class="zaakzaw5 input" autocomplete="off" />
                          </label><br clear="left" /><div class="formError zaakeorr1" id="pan_error1"> </div></td>
                      </tr>
                      
                      <tr >
                        <td colspan="4"  height="5" bgcolor="#ffffff" ></td>
                      </tr>
                      <tr >
                        <td class="zaakpay-7-1">Expiration Date</td>
                        <td>
                           
                           <select class="select" name="expiry_month1" id="expiry_month1" style="width:50px;">
                            <option value="mm">mm</option>
                            <option value="1">01 </option>
                            <option value="2">02 </option>
                            <option value="3">03 </option>
                            <option value="4">04 </option>
                            <option value="5">05 </option>
                            <option value="6">06 </option>
                            <option value="7">07 </option>
                            <option value="8">08 </option>
                            <option value="9">09 </option>
                            <option value="10">10 </option>
                            <option value="11">11 </option>
                            <option value="12">12 </option>
                          </select>
                          /
                          <select class="select" name="expiry_year1" id="expiry_year1" style="width:50px;">
                            <option value="yy">yy</option>                           
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                          </select><br clear="left" /><div class="formError zaakeorr1" id="expiry_error1" > </div></td>
                          
                          <td class="zaakpay-7-2">CVV Code</td>
                        <td><label for="cvv1">
                            <input type="password" name="cvv1" id="cvv1" class="input" maxlength="3" style="width:40px"/>
                          
                          </label> <a href="javascript:void(0);" style="font:bold 12px Arial, Helvetica, sans-serif; padding:0px 0 0 10px;; color:#000000;" onmouseover="alerts_show('alerts_pop5');" onmouseout="alerts_hide('alerts_pop5')" title="">What is This</a><br clear="left" />
                          <div class=" formError zaakeorr1" id="cvv_error1" > </div></td>
                          
                          
                      </tr>
                      
                      <tr >
                        <td colspan="4"  height="5" bgcolor="#ffffff" ></td>
                      </tr>
                      <tr >
                        <td class="zaakpay-7-1">Name On Card</td>
                        <td><label for="nameoncard1">
                            <input type="text" name="nameoncard1" id="nameoncard1"  value="Buyer Fn Ln" class="input" maxlength="100" autocomplete="off"/>
                          </label><br clear="left" /><div class="formError zaakeorr1" id="nameoncard_error1"> </div></td>
                       
                      </tr>
                    
                      
                    </table>
                  </div>
                  
                  <div class="zaakpay-6">
                    <div class="zaakeorr" >
                      <div class="formError">
                        <h2></h2>
                      </div>
                    </div>
                  </div>
                  
                  <div class="zaakpay-4">
                    <div class="zaakpay-4-l">
                     <div id="loader1"><img src="/images/loader.gif" width="40" height="40" align="middle"/> &nbsp;Please Wait....</div>
                      <div class="zaakblue" id="paynow1">
                        <h2><a href="javascript:submitForm1();" >Pay Now</a></h2>
                      </div>
                    </div>
                    <div class="zaakpay-4-r"><div class="powerby"></div></div>
                  </div>
                </div>
             
              </div>
              
            
          </div>
            
          
        </div>
      </div> 
    </div> 
    
    <div class="zaakmiddlecont" >
      <div class="zaakmaster">
         	<div id="netbank" style="display:none;">
       
          <div class="zaakmiddlebottom" style="height:250px;">    
          
          
            
<div class="ecssing">




<table width="650px;">
<tr>
	<td colspan="2" align="center" valign="middle"></td>
	
</tr>


</table>

</div>
 
              <div class="zaakpayboxe" id="selector">
               
                <div class="zaakpaynav">
                  <ul>
                    <li><a href="javascript:showCredit()">Credit Card</a></li>
                    <li><a href="javascript:showDebit();" >Debit Card</a></li>
                 <li><a href="javascript:showNetBank();"  class="selected">Net Banking</a></li>
                  </ul>
                </div>
                <!--end-nav-->
             
             	
              	<div class="zaakpaysection" style="border-top:none;">
                <!--  <h2>How to pay by Bank Account (Net Banking, Internet Banking, Online Banking)</h2>-->
                
                	<div class="zaakpay-1" style="display: none;">
                    <div class="zaakpay-1-reuseable-l">1</div>
                    <div class="zaakpay-1-reuseable-2">Choose your <br/>Bank Account</div>
                    <div class="zaakpay-1-reuseable-l">2</div>
                    <div class="zaakpay-1-reuseable-2 ">Confirm transaction on<br/>your bank's website</div>
                    <div class="zaakpay-1-reuseable-l">3</div>
                    <div class="zaakpay-1-reuseable-2">Come back to see your <br/>transaction status</div>
                    
                  </div>
                  <div class="zaakpay-2">
                    <div class="zaakpay-2-l" style="margin:13px 0 0 0;"></div>
                    <br/>
                    <div class="zaakpay-2-r">
                       <h2>My bank is </h2>
   
		<select name="bankid" id="bankid" >
					<option value="NULL">Choose your Bank</option>		
								<option value="SBI">State Bank of India</option>
								<option value="HDF">HDFC Bank</option>
								<!-- <option>ICICI Bank</option>
								<option>Axis Bank</option>  -->
                                <option value="NULL">__________________</option>							

				    <option value="ALB">Allahabad Bank</option>
					<option value="ADB">Andhra Bank</option>
					<option value="BBK">Bank of Bahrain and Kuwait</option>
					<option value="BBC">Bank of Baroda - Corporate Banking</option>
					<option value="BBR">Bank of Baroda - Retail Banking</option>
					<option value="BOI">Bank of India</option>
					<option value="BOM">Bank of Maharashtra</option>
					<option value="CNB">Canara Bank</option>
					<option value="CSB">Catholic Syrian Bank</option>
					<option value="CBI">Central Bank of India</option>
					<option value="CUB">City Union Bank</option>
					<option value="CRP">Corporation Bank</option>
					<option value="DEN">Dena Bank</option>
					<option value="DBK">Deutsche Bank</option>
					<option value="DCB">Development Credit Bank</option>
					<option value="DLB">Dhanlakshmi Bank</option>
					<option value="FBK">Federal Bank</option>
					<option value="IDB">IDBI Bank</option>
					<option value="INB">Indian Bank</option>
					<option value="IOB">Indian Overseas Bank</option>
					<option value="IDS">IndusInd Bank</option>
					<option value="ING">ING Vysya Bank</option>
					<option value="JKB">Jammu & Kashmir Bank</option>
					<option value="KBL">Karnataka Bank Ltd</option>
					<option value="KVB">Karur Vysya Bank</option>
					<!-- <option>Kotak Bank</option> -->
					<option value="LVC">Laxmi Vilas Bank - Corporate Net Banking</option>
					<option value="LVR">Laxmi Vilas Bank - Retail Net Banking</option>
					<option value="OBC">Oriental Bank of Commerce</option>
					<option value="PSB">Punjab &amp; Sind Bank</option>
					<option value="CPN">Punjab National Bank - Corporate Banking</option>
					<option value="PNB">Punjab National Bank - Retail Banking</option>
					<option value="RTN">Ratnakar Bank</option>
					<option value="SVC">Shamrao Vitthal Co-operative Bank</option>
					<option value="SIB">South Indian Bank</option>
					<option value="SBJ">State Bank of Bikaner & Jaipur</option>
					<option value="SBH">State Bank of Hyderabad</option>
					<option value="SBM">State Bank of Mysore</option>
					<option VALUE="SBP">State Bank of Patiala</option>
					<option VALUE="SBT">State Bank of Travancore</option>
					<option value="SYD">Syndicate Bank</option>
					<option value="TMB">Tamilnad Mercantile Bank Ltd.</option>
					<option value="UCO">UCO Bank</option>
					<option value="UBI">Union Bank of India</option>
					<option value="UNI">United Bank of India</option>
					<option value="VJB">Vijaya Bank</option>
					<option value="YBK">Yes Bank Ltd</option>					
				</select>
              </label>
                 
                      <div id="bankid_error" class="zaakeorr" style="padding:3px 0 2px 142px;"></div>
                    </div>
                  </div>          
                 
               
                  <div class="zaakpay-4">
                    <div class="zaakpay-4-l">
                    <div id="loader2"><img src="images/loader.gif" width="40" height="40" align="left"/>&nbsp; Please Wait...</div>
                      <div id="paynow2" class="zaakblue">
                        <h2><a href="javascript:submitFormNetBanking();" >Pay Now</a></h2>
                      </div>
                    </div>
                    <div class="zaakpay-4-r"><div class="powerby"></div></div>
                  </div>
                </div>
              
                <!--zaakpaysection--> 
             </div>
                           
            </form>
         
          
          
          </div><!--zaakmiddlebottom-->
        
         </div> <!-- id--debit-->
          </div><!--zaakmaster-->
         </div><!-- zaakmiddlecont-->
    
       <!--NET BANKING -->
    
  </div>
    
  </div>
  
  
		
</body>
</html>