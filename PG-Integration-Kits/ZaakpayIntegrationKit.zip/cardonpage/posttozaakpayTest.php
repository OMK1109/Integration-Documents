<?php
require_once('lib/checksum.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Zaakpay</title>
<script type="text/javascript">
function submitForm(){
			var form = document.forms[0];
			form.submit();
		}
</script>
</head>
<body onload="javascript:submitForm()">
<center>
<table width="500px;">
	<tr>
		<td align="center" valign="middle">Do Not Refresh or Press Back <br/> Redirecting to Zaakpay</td>
	</tr>
	<tr>
		<td align="center" valign="middle">
			<form action="https://api.zaakpay.com/transactD?v=3" method="post">
				<input type="hidden" name="merchantIdentifier" value="<?php echo Checksum::sanitizedParam($_POST['merchantIdentifier']); ?>" />
				<input type="hidden" name="checksum" value="<?php echo $_POST['checksum']; ?>" />
				<input type="hidden" name="orderId" value="<?php echo Checksum::sanitizedParam($_POST['orderId']); ?>" />
				<input type="hidden" name="returnUrl" value="<?php echo Checksum::sanitizedURL($_POST['returnUrl']); ?>" />
				<input type="hidden" name="showMobile" value="<?php echo Checksum::sanitizedParam($_POST['showMobile']); ?>" />
				<input type="hidden" name="buyerEmail" value="<?php echo Checksum::sanitizedParam($_POST['buyerEmail']); ?>" />
				<input type="hidden" name="buyerFirstName" value="<?php echo Checksum::sanitizedParam($_POST['buyerFirstName']); ?>" />
				<input type="hidden" name="buyerLastName" value="<?php echo Checksum::sanitizedParam($_POST['buyerLastName']); ?>" />
				<input type="hidden" name="buyerAddress" value="<?php echo Checksum::sanitizedParam($_POST['buyerAddress']); ?>" />
				<input type="hidden" name="buyerCity" value="<?php echo Checksum::sanitizedParam($_POST['buyerCity']); ?>" />
				<input type="hidden" name="buyerState" value="<?php echo Checksum::sanitizedParam($_POST['buyerState']); ?>" />
				<input type="hidden" name="buyerCountry" value="<?php echo Checksum::sanitizedParam($_POST['buyerCountry']); ?>" />
				<input type="hidden" name="buyerPincode" value="<?php echo Checksum::sanitizedParam($_POST['buyerPincode']); ?>" />
				<input type="hidden" name="buyerPhoneNumber" value="<?php echo Checksum::sanitizedParam($_POST['buyerPhoneNumber']); ?>" />
				<input type="hidden" name="txnType" value="<?php echo Checksum::sanitizedParam($_POST['txnType']); ?>" />
				<input type="hidden" name="zpPayOption" value="<?php echo Checksum::sanitizedParam($_POST['zpPayOption']); ?>" />
				<input type="hidden" name="mode" value="<?php echo Checksum::sanitizedParam($_POST['mode']); ?>" />
				<input type="hidden" name="currency" value="<?php echo Checksum::sanitizedParam($_POST['currency']); ?>" />
				<input type="hidden" name="amount" value="<?php echo Checksum::sanitizedParam($_POST['amount']); ?>" />
				<input type="hidden" name="merchantIpAddress" value="<?php echo Checksum::sanitizedParam($_POST['merchantIpAddress']); ?>" />
				<input type="hidden" name="purpose" value="<?php echo Checksum::sanitizedParam($_POST['purpose']); ?>" />
				<input type="hidden" name="productDescription" value="<?php echo Checksum::sanitizedParam($_POST['productDescription']); ?>" />
				<input type="hidden" name="product1Description" value="<?php echo Checksum::sanitizedParam($_POST['product1Description']); ?>" />
				<input type="hidden" name="product2Description" value="<?php echo Checksum::sanitizedParam($_POST['product2Description']); ?>" />
				<input type="hidden" name="product3Description" value="<?php echo Checksum::sanitizedParam($_POST['product3Description']); ?>" />
				
				<input type="hidden" name="shipToAddress" value="<?php echo Checksum::sanitizedParam($_POST['shipToAddress']); ?>" />
				<input type="hidden" name="shipToCity" value="<?php echo Checksum::sanitizedParam($_POST['shipToCity']); ?>" />
				<input type="hidden" name="shipToState" value="<?php echo Checksum::sanitizedParam($_POST['shipToState']); ?>" />
				<input type="hidden" name="shipToCountry" value="<?php echo Checksum::sanitizedParam($_POST['shipToCountry']); ?>" />
				<input type="hidden" name="shipToPincode" value="<?php echo Checksum::sanitizedParam($_POST['shipToPincode']); ?>" />
				<input type="hidden" name="shipToPhoneNumber" value="<?php echo Checksum::sanitizedParam($_POST['shipToPhoneNumber']); ?>" />
				<input type="hidden" name="shipToFirstname" value="<?php echo Checksum::sanitizedParam($_POST['shipToFirstname']); ?>" />
				<input type="hidden" name="shipToLastname" value="<?php echo Checksum::sanitizedParam($_POST['shipToLastname']); ?>" />
				<input type="hidden" name="txnDate" value="<?php echo Checksum::sanitizedParam($_POST['txnDate']); ?>" />
				
				
				<!-- new params -->
				<input type="hidden" name="debitorcredit" value="<?php echo $_POST['debitorcredit']; ?>" />
				
				<?php if($_POST['debitorcredit']=="netbanking")
				{ ?>
				<input type="hidden" name="bankid" value="<?php echo $_POST['bankid']; ?>" />
				<?php }
				else
				{ ?>
				
				<input type="hidden" name="encrypted_pan" value="<?php echo $_POST['encrypted_pan']; ?>" />
				<input type="hidden" name="card" value="<?php echo $_POST['card']; ?>" />
				<input type="hidden" name="nameoncard" value="<?php echo $_POST['nameoncard']; ?>" />
				<input type="hidden" name="encryptedcvv" value="<?php echo $_POST['encryptedcvv']; ?>" />
				<input type="hidden" name="encrypted_expiry_month" value="<?php echo $_POST['encrypted_expiry_month']; ?>" />
				<input type="hidden" name="encrypted_expiry_year" value="<?php echo $_POST['encrypted_expiry_year']; ?>" />
				<?php }
				?>
			
			</form>
		</td>

	</tr>

</table>

</center>	
</body>
</html>
