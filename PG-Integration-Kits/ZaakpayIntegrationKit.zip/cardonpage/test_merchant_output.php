<?php

require_once('Constants.php');
require_once('lib/checksum.php');

$all = Checksum::getAllParams();
$checksum = Checksum::calculateChecksum(SECRETKEY, $all);

$isChecksumValid = false;

if($checksum == $_REQUEST['checksum'])
{
$isChecksumValid = true;
}
var_dump($_POST);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Zaakpay</title>
<style type="text/css">
.center{ width:800px; margin:50px auto;}
.heading{ width:815px; float:left; background-color:#1c373f; padding:0 0 0 5px; -webkit-border-radius: 10px 10px 0 0; -moz-border-radius: 10px 10px 0 0; border-radius: 10px 10px 0 0; border:2px solid #333333; border-bottom:none; }
.heading h2 {padding:10px 0 10px 0;margin: 0; font:bold 30px Calibri, Arial, Helvetica, sans-serif;text-align:Center;color:#ffffff;}
.outer{-webkit-border-radius:0 0 10px 10px; -moz-border-radius:0 0 10px 10px; border-radius:0 0 10px 10px; /*box-shadow: 0px 0px 5px #2d2d2d; border:5px solid #737070;*/border:2px solid #333333; border-top:none; padding: 40px 10px; width: 800px; float:left; font:normal 14px/20px Arial, sans-serif; text-align:center;  background-color: #e9f0f2;"}

</style>


<script type="text/javascript" src="/javascripts/ga.js"></script>
 
</head>
<body>


	<div class="center">
     <div class="heading"><img src="/images/zaakpaylogobeta.gif" alt=""  align="left" />
    <h2>Example Payment Confirmation Page</h2>   
    </div>
    <div class="outer">
   
<table cellpadding="0" cellspacing="0" border="0" width="800px;">

				
			<tr>
				<td width="40%" style="text-align:right;"  valign="middle">Order Id</td>
                 <td  width="10%"></td>
				<td width="50%" style="text-align:left;" valign="middle"><?php echo $_POST['orderId']; ?> </td>
			</tr>
			
		
			
			<tr>
				<td  colspan="3" style="text-align:center; padding-top:5px;"  valign="middle"><strong><?php echo $_POST['responseCode']; ?>  <?php echo $_POST['responseDescription']; ?></strong></td>
			</tr>
			<?php if($_POST['amount'] != null){ ?>
			<tr>
				<td  width="40%" style="text-align:right;"  valign="middle">Amount</td>
                 <td  width="10%"></td>
				<td width="50%" style="text-align:left;"  valign="middle"><?php echo $_POST['amount']; ?></td>
			</tr>
			<?php }if($isChecksumValid){ ?>
			<tr>
				
				<td colspan="3"  style="text-align:center; padding-top:5px;"  valign="middle">Checksum was verified successfully</td>
			</tr>
			<?php }  else { ?>
			<tr>
			
			<td colspan="3"  style="text-align:center; padding-top:5px; color: red;"  valign="middle">Checksum Failed</td>
		</tr>
		<?php } 
			
			if(isset($_POST['transactionId'])){ ?>
			<tr>
				<td width="40%" style="text-align:right;"  valign="middle">Transaction Id </td>
                 <td  width="10%"></td>
				<td width="50%" style="text-align:left;"  valign="middle"><?php echo $_POST['transactionId']; ?></td>
			</tr>
			<?php } ?>
		
		</table>
		</table>
		</table>
	
	
	</div>
	</div>
</body>
</html>
