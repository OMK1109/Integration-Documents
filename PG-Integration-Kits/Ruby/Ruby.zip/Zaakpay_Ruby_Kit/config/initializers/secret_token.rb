# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ZaakpayDemo::Application.config.secret_token = '0dbbf11578e3d44e0f052dd181cef3d821f11135c43da381de82e15b81fdb620e9a5db3050f6c8c159bf0a239b28c06a93611a3d6742ae08ace21b1a9201d463'
