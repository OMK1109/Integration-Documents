<?php
// Text
$_['text_title']        = 'Zaakpay';
$_['heading_title']     = 'Zaakpay';
$_['text_payment']		= 'Payment';
$_['button_confirm']		='Button_confrim';
?>
