<?php
// Text
$_['heading_title']     = 'Zaakpay';
$_['text_title'] = 'Simplifying payments in India';
?>
