class Postthis:			

	def __init__(self,postdata):
		self.post_data = postdata
    
	def outputForm(self):
		a=''
		for key in self.post_data.iterkeys():
 			a += '<input type="hidden" name="merchantIdentifier" value="' + self.post_data['merchantIdentifier'] + '"/>'
			a += '<input type="hidden" name="checksum" value="' + self.post_data['checksum'] + '"/>'
			a += '<input type="hidden" name="orderId" value="' + self.post_data['orderId'] + '"/>'
			a += '<input type="hidden" name="returnUrl" value="' + self.post_data['returnUrl'] + '"/>'
			a += '<input type="hidden" name="buyerEmail" value="' + self.post_data['buyerEmail'] + '"/>'
			a += '<input type="hidden" name="buyerFirstName" value="' + self.post_data['buyerFirstName'] + '"/>'
			a += '<input type="hidden" name="buyerLastName" value="' + self.post_data['buyerLastName'] + '"/>'
			a += '<input type="hidden" name="buyerAddress" value="' + self.post_data['buyerAddress'] + '"/>'
			a += '<input type="hidden" name="buyerCity" value="' + self.post_data['buyerCity'] + '"/>'
			a += '<input type="hidden" name="buyerState" value="' + self.post_data['buyerState'] + '"/>'
			a += '<input type="hidden" name="buyerCountry" value="' + self.post_data['buyerCountry'] + '"/>'
			a += '<input type="hidden" name="buyerPincode" value="' + self.post_data['buyerPincode'] + '"/>'
			a += '<input type="hidden" name="buyerPhoneNumber" value="' + self.post_data['buyerPhoneNumber'] + '"/>'
			a += '<input type="hidden" name="txnType" value="' + self.post_data['txnType'] + '"/>'
			a += '<input type="hidden" name="zpPayOption" value="' + self.post_data['zpPayOption'] + '"/>'
			a += '<input type="hidden" name="mode" value="' + self.post_data['mode'] + '"/>'
			a += '<input type="hidden" name="currency" value="' + self.post_data['currency'] + '"/>'
			a += '<input type="hidden" name="amount" value="' + self.post_data['amount'] + '"/>'
			a += '<input type="hidden" name="merchantIpAddress" value="' + self.post_data['merchantIpAddress'] + '"/>'
			a += '<input type="hidden" name="purpose" value="' + self.post_data['purpose'] + '"/>'
			a += '<input type="hidden" name="productDescription" value="' + self.post_data['productDescription'] + '"/>'
			a += '<input type="hidden" name="product1Description" value="' + self.post_data['product1Description'] + '"/>'
			a += '<input type="hidden" name="product2Description" value="' + self.post_data['product2Description'] + '"/>'
			a += '<input type="hidden" name="product3Description" value="' + self.post_data['product3Description'] + '"/>'
			a += '<input type="hidden" name="shipToAddress" value="' + self.post_data['shipToAddress'] + '"/>'
			a += '<input type="hidden" name="shipToCity" value="' + self.post_data['shipToCity'] + '"/>'
			a += '<input type="hidden" name="shipToState" value="' + self.post_data['shipToState'] + '"/>'
			a += '<input type="hidden" name="shipToCountry" value="' + self.post_data['shipToCountry'] + '"/>'
			a += '<input type="hidden" name="shipToPincode" value="' + self.post_data['shipToPincode'] + '"/>'
			a += '<input type="hidden" name="shipToPhoneNumber" value="' + self.post_data['shipToPhoneNumber'] + '"/>'
			a += '<input type="hidden" name="shipToFirstname" value="' + self.post_data['shipToFirstname'] + '"/>'
			a += '<input type="hidden" name="shipToLastname" value="' + self.post_data['shipToLastname'] + '"/>'
			a += '<input type="hidden" name="txnDate" value="' + self.post_data['txnDate'] + '"/>'

			a += '<input type="hidden" name="debitorcredit" value="' + self.post_data['debitorcredit'] + '"/>'
			
			if(self.post_data['debitorcredit'] == "netbanking"):
			    a += '<input type="hidden" name="bankid" value="' + self.post_data['bankid'] + '"/>'
			else:
			    a += '<input type="hidden" name="encrypted_pan" value="' + self.post_data['encrypted_pan'] + '"/>'
			    a += '<input type="hidden" name="card" value="' + self.post_data['card'] + '"/>'
			    a += '<input type="hidden" name="nameoncard" value="' + self.post_data['nameoncard'] + '"/>'
			    a += '<input type="hidden" name="encryptedcvv" value="' + self.post_data['encryptedcvv'] + '"/>'
			    a += '<input type="hidden" name="encrypted_expiry_month" value="' + self.post_data['encrypted_expiry_month'] + '"/>'
			    a += '<input type="hidden" name="encrypted_expiry_year" value="' + self.post_data['encrypted_expiry_year'] + '"/>'
		return a
