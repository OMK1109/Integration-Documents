from django.core.context_processors import csrf
from django.shortcuts import render_to_response
from django.shortcuts import render
from django.http import HttpResponse
from checksum import *
from post import *
from django.views.decorators.csrf import csrf_exempt
from django.template import RequestContext
import os
from os.path import abspath, dirname

def index(request):
	return render(request, 'zaakpay/merchant.html')

@csrf_exempt
def posttozaakpay(request):
	if request.method == 'POST':
                post_data1 = {}
		checksum_data = {}
		data1 = request.POST
		for x in data1:
			post_data1[x] = data1[x]
        	
		checksum_var1 = Checksum(post_data1)
		mid = data1['merchantIdentifier']
	        oid = data1['orderId']
	        mode = data1['mode']
	        curr = data1['currency']
	        amount = data1['amount']
	        mip = data1['merchantIpAddress']
	        date = data1['txnDate']
		alld = "'"+mid+"''"+oid+"''"+mode+"''"+curr+"''"+amount+"''"+mip+"''"+date+"'"
		checks_cal = checksum_var1.calculateChecksum(secret, alld)
		a = checksum_var1.outputForm(checks_cal)
		html_temp1 = open(os.getcwd() +  '/template/zaakpay/card.html').read()
		out = html_temp1 % a   
	return HttpResponse(out)

@csrf_exempt
def post(request):
	if request.method == 'POST':
		data2 = request.POST
		post_data2 = {}
		for x in data2:
			post_data2[x] = data2[x]
		post_var = Postthis(post_data2)
		getdata = post_var.outputForm()
		html_temp2 = open(os.getcwd() +  '/template/zaakpay/post.html').read()
		output = html_temp2 % getdata
	return HttpResponse(output)

@csrf_exempt
def response(request):
    	if request.method =='POST':
		post_data3 = {}
		data3 = request.POST
		for x in data3:
			post_data3[x] = data3[x]
	recvd_checksum = data3['checksum']
	oid = data3['orderId']
	resc = data3['responseCode']
	resd = data3['responseDescription']
	amount = data3['amount']
	paymet = data3['paymentMethod']
	cardhid = data3['cardhashid']
	alldata1 = "'"+oid+"''"+resc+"''"+resd+"''"+amount+"''"+paymet+"''"+cardhid+"'" 
	print alldata1
	checksum2 = Checksum(post_data3)
	alldata2 = checksum2.getAllParams()
	checksum_cal = checksum2.calculateChecksum(secret, alldata1)
	checksum_check = checksum2.verifyChecksum(recvd_checksum, alldata1, secret)
	a2 = checksum2.outputResponse(checksum_check)
	html_template2 = open(os.getcwd() +  '/template/zaakpay/response.html').read()
        output2 = html_template2 % a2
	return HttpResponse(output2)

