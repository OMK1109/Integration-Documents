
function showDebit(){

document.getElementById('netbank').style.visibility='hidden';
document.getElementById('debit').style.visibility='visible';
document.getElementById('credit').style.visibility='hidden';
document.getElementById('netbank').style.display='none';
document.getElementById('debit').style.display='block';
document.getElementById('credit').style.display='none';
document.getElementById('mobikwik').style.display='none';
}
function showNetBank(){
document.getElementById('netbank').style.visibility='visible';
document.getElementById('debit').style.visibility='hidden';
document.getElementById('credit').style.visibility='hidden';
document.getElementById('netbank').style.display='block';
document.getElementById('debit').style.display='none';
document.getElementById('credit').style.display='none';
document.getElementById('mobikwik').style.display='none';
}
function showCredit(){
document.getElementById('netbank').style.visibility='hidden';
document.getElementById('debit').style.visibility='hidden';
document.getElementById('credit').style.visibility='visible';
document.getElementById('netbank').style.display='none';
document.getElementById('debit').style.display='none';
document.getElementById('credit').style.display='block';
document.getElementById('mobikwik').style.display='none';
}
function showMobikwik(){
document.getElementById('netbank').style.visibility='hidden';
document.getElementById('debit').style.visibility='hidden';
document.getElementById('credit').style.visibility='hidden';
document.getElementById('netbank').style.display='none';
document.getElementById('debit').style.display='none';
document.getElementById('credit').style.display='none';
document.getElementById('mobikwik').style.display='block';
document.getElementById('mobikwik').style.display='visible';
}
function alerts_show(id) {
document.getElementById(id).style.display = 'block';
}
function alerts_hide(id) {
document.getElementById(id).style.display = 'none';
}
  function getFormElement(frm, id){
	for(var i=0;
i < frm.elements.length;
i++){
		var element = frm.elements[i];
		if(element.id != null && element.id == id){
			return element;
		}
	}
}
function submitForm0(){
	 	var form = document.forms[0];
		if(validateCreditCardForm(form)){
			form.action = '/zaakpay/post/';
			/*clearcardfields();
*/ 			document.getElementById('loader0').style.display = 'block';
			document.getElementById('loader0').style.visibility = 'visible';
			document.getElementById('paynow0').style.display = 'none';
			document.getElementById('paynow0').style.visibility = 'hidden';
			document.getElementById('debitorcredit').value='debit';
			form.submit();
		}
		 }
 function validateCreditCardForm(frm){
	 	if(!(cardtypeval0(frm) && cardval0() && exp_date0('') && cvvval0() && nameoncardval0() )){
		return false;
	 	}
	return true;
}
function cardval0() {
	 	s=document.forms[0].elements['pan1'].value;
	if(s == ''){
		document.getElementById('pan_error0').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan1'].focus();
		return false;
	}
	 	s=document.forms[0].elements['pan2'].value;
	if(s == ''){
		document.getElementById('pan_error0').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan2'].focus();
		return false;
	}
	 	s=document.forms[0].elements['pan3'].value;
	if(s == ''){
		document.getElementById('pan_error0').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan3'].focus();
		return false;
	}
	s=document.forms[0].elements['pan4'].value;
	if(s == ''){
		document.getElementById('pan_error0').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan4'].focus();
		return false;
	}
	 	document.getElementById('pan_error0').innerHTML='';
	s = document.forms[0].elements['pan1'].value + document.forms[0].elements['pan2'].value + document.forms[0].elements['pan3'].value + 		
	document.forms[0].elements['pan4'].value;
	 	 	var v = '0123456789';
	var w = '';
	 	for (var i=0;
i  <  s.length;
i++) {
	x = s.charAt(i);
	if (v.indexOf(x,0) != -1) {
		w += x;
	}
else {
		document.getElementById('pan_error0').innerHTML='You have entered an invalid card number.';
		document.forms[0].elements['pan1'].focus();
		return false;
	}
	}
	 	j = w.length / 2;
	if (j  <  6.5 || j > 8 || j == 7) 		{
	 			 			document.getElementById('pan_error0').innerHTML='You have entered an invalid card number.';
			document.forms[0].elements['pan1'].focus();
			return false;
		}
else{
			document.getElementById('pan_error0').innerHTML='';
		}
	k = Math.floor(j);
	m = Math.ceil(j) - k;
	c = 0;
	for (i=0;
i < k;
i++) {
	a = w.charAt(i*2+m) * 2;
	c += a > 9 ? Math.floor(a/10 + a%10) : a;
	}
	for (var i=0;
i < k+m;
i++) c += w.charAt(i*2+1-m) * 1;
	if (!(c%10 == 0)) 	{
	 		document.getElementById('pan_error0').innerHTML='You have entered an invalid card number.';
		document.forms[0].elements['pan1'].focus();
		 		return false;
	}
else{
		 		document.getElementById('pan_error0').innerHTML='';
	}
	 	 	document.forms[0].elements['encrypted_pan'].value = encryptField(s);
	 	return true;
	}
function exp_date0(cc){
	 	var m=document.forms[0].elements['expiry_month0'];
	var y=document.forms[0].elements['expiry_year0'];
	
	var str='';
	str=m.value+y.value;
	if(m.value == 'mm' ) 	{
		 		document.getElementById('expiry_error0' + cc).innerHTML='Please select Month of Expiry date!';
		document.forms[0].elements['expiry_month0'].focus();
		return false;
	}
else if(y.value == 'yy'){
		 		document.getElementById('expiry_error0' + cc).innerHTML='Please select Year of Expiry date!';
		document.forms[0].elements['expiry_year0'].focus();
		return false;
	}
else{
		document.getElementById('expiry_error0' + cc).innerHTML='';
	}
	 	var currentDate = new Date();
	var currentYear=currentDate.getFullYear();
	var currentMonth=currentDate.getMonth()+1;
	 	var cy = currentYear - 2000;
	y = parseInt(y.value);
	m = parseInt(m.value);
	 	if (y  <  cy) {
		document.getElementById('expiry_error0' + cc).innerHTML='Card Expired!';
		document.forms[0].elements['expiry_year0'].focus();
		return false;
	}
	 	if (y == cy) {
		if (m  <  currentMonth) {
			document.getElementById('expiry_error0' + cc).innerHTML='Card Expired!';
			document.forms[0].elements['expiry_month0'].focus();
			return false;
		}
	}
	 	if(str.length==4 || str.length==3) 	{
			
			 			document.forms[0].elements['encrypted_expiry_month'].value = encryptField(document.forms[0].elements['expiry_month0'].value);
			document.forms[0].elements['encrypted_expiry_year'].value = encryptField(document.forms[0].elements['expiry_year0'].value);
			 			return true;
	}
	else  	{
		document.getElementById('expiry_error0' + cc).innerHTML='Invalid value in expiry date!';
		document.forms[0].elements['expiry_year0'].focus();
		return false;
	}
	 }
   function cvvval0(){
	  
	var cvv=document.forms[0].elements['cvv0'];
	if(cvv.value == ''){
		document.getElementById('cvv_error0').innerHTML='Please enter your cvv code.';
		document.forms[0].elements['cvv0'].focus();
		return false;
	}
else{
		document.getElementById('cvv_error0').innerHTML='';
		document.forms[0].elements['encryptedcvv'].value = encryptField(cvv.value);
		return true;
	}
	 }
function nameoncardval0(){
	var nameoncardval = document.forms[0].elements['nameoncard0'];
	if(nameoncardval.value == ''){
		document.getElementById('nameoncard_error0').innerHTML='Please enter name on Card.';
		document.forms[0].elements['nameoncard0'].focus();
		return false;
	}
else{
		document.getElementById('nameoncard_error0').innerHTML='';
		document.forms[0].elements['nameoncard'].value=nameoncardval.value;
		return true;
	}
}
    function cardtypeval0(frm){
	 	var visa = getFormElement(frm, 'visa');
	var master = getFormElement(frm, 'master');
	if(visa.checked || master.checked){
		document.getElementById('cardtype_error0').innerHTML='';
		if(visa.checked)
		document.forms[0].elements['card'].value=visa.value;
		if(master.checked)
		document.forms[0].elements['card'].value=master.value;
		return true;
	}
else{
		document.getElementById('cardtype_error0').innerHTML='Please Select Card Type.';
		 		visa.focus();
		return false;
	}
	 }
 function submitForm1(){
	var form = document.forms[0];
	if(validateDebitCardForm(form)) 	{
		form.action = '/zaakpay/post/';
		/*clearcardfields();
*/ 		document.getElementById('loader1').style.display = 'block';
		document.getElementById('loader1').style.visibility = 'visible';
		document.getElementById('paynow1').style.display = 'none';
		document.getElementById('paynow1').style.visibility = 'hidden';
		document.getElementById('debitorcredit').value='credit';
		form.submit();
	}
}
function validateDebitCardForm(frm){
	 	if(!(cardtypeval1() && cardval1() && exp_date1('1')&& cvvval1() && nameoncardval1()/* && add1val1() && cityval1() &&  pin_code1() && countryval1()*/)){
		return false;
	 	}
	return true;
}
function cardval1() {
	s=document.forms[0].elements['pan5'].value;
	if(s == ''){
		document.getElementById('pan_error1').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan5'].focus();
		return false;
	}
	 	s=document.forms[0].elements['pan6'].value;
	if(s == ''){
		document.getElementById('pan_error1').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan6'].focus();
		return false;
	}
	 	s=document.forms[0].elements['pan7'].value;
	if(s == ''){
		document.getElementById('pan_error1').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan7'].focus();
		return false;
	}
	s=document.forms[0].elements['pan8'].value;
	if(s == ''){
		document.getElementById('pan_error1').innerHTML='Please enter your card number.';
		document.forms[0].elements['pan8'].focus();
		return false;
	}
	 	document.getElementById('pan_error1').innerHTML='';
	s = document.forms[0].elements['pan5'].value + document.forms[0].elements['pan6'].value + document.forms[0].elements['pan7'].value + 		document.forms[0].elements['pan8'].value;
 	 	var v = '0123456789';
	var w = '';
	for (i=0;
i  <  s.length;
i++) {
	x = s.charAt(i);
	if (v.indexOf(x,0) != -1) {
	w += x;
	}
else {
			document.getElementById('pan_error1').innerHTML='You have entered an invalid card number';
			document.forms[0].elements['pan5'].focus();
			return false;
		}
	}
		 	 	j = w.length / 2;
	if (j  <  6.5 || j > 8 || j == 7) 		{
	 			document.getElementById('pan_error1').innerHTML='You have entered an invalid card number';
			document.forms[0].elements['pan5'].focus();
			return false;
		}
	k = Math.floor(j);
	m = Math.ceil(j) - k;
	c = 0;
	for (i=0;
i < k;
i++) {
	a = w.charAt(i*2+m) * 2;
	c += a > 9 ? Math.floor(a/10 + a%10) : a;
	}
	for (i=0;
i < k+m;
i++) c += w.charAt(i*2+1-m) * 1;
	if (!(c%10 == 0)) 	{
	 		document.getElementById('pan_error1').innerHTML='You have entered an invalid card number';
		document.forms[0].elements['pan5'].focus();
		return false;
	}
else{
		 		document.getElementById('pan_error1').innerHTML='';
	}
	 	document.forms[0].elements['encrypted_pan'].value = encryptField(s);
	 	return true;
	}
function exp_date1(){
	var m=document.forms[0].elements['expiry_month1'];
	var y=document.forms[0].elements['expiry_year1'];
	
	var str='';
	str=m.value+y.value;
	if(m.value == 'mm' ) 	{
		document.getElementById('expiry_error1').innerHTML='Please select Month of Expiry date!';
		document.forms[0].elements['expiry_month1'].focus();
		return false;
	}
else if(y.value == 'yy'){
		document.getElementById('expiry_error1').innerHTML='Please select Year of Expiry date!';
		document.forms[0].elements['expiry_year1'].focus();
		return false;
	}
else{
		document.getElementById('expiry_error1').innerHTML='';
	}
	 	var currentDate = new Date();
	var currentYear=currentDate.getFullYear();
	var currentMonth=currentDate.getMonth()+1;
	 	var cy = currentYear - 2000;
	y = parseInt(y.value);
	m = parseInt(m.value);
	 	if (y  <  cy) {
		document.getElementById('expiry_error1').innerHTML='Card Expired!';
		document.forms[0].elements['expiry_year1'].focus();
		return false;
	}
	 	if (y == cy) {
		if (m  <  currentMonth) {
			document.getElementById('expiry_error1').innerHTML='Card Expired!';
			document.forms[0].elements['expiry_month1'].focus();
			return false;
		}
	}
	if(str.length==4 || str.length==3) 	{
			
			document.forms[0].elements['encrypted_expiry_month'].value = encryptField(document.forms[0].elements['expiry_month1'].value);
			document.forms[0].elements['encrypted_expiry_year'].value = encryptField(document.forms[0].elements['expiry_year1'].value);
					 			return true;
	}
	else 	{
		document.getElementById('expiry_error1').innerHTML='Invalid value in expiry date!';
		document.forms[0].elements['expiry_year1'].focus();
		return false;
	}
	 }
 function cvvval1(){
	var cvv=document.forms[0].elements['cvv1'];
	if(cvv.value == ''){
		document.getElementById('cvv_error1').innerHTML='Please enter your cvv code.';
		document.forms[0].elements['cvv1'].focus();
		return false;
	}
else{
		document.getElementById('cvv_error1').innerHTML='';
		document.forms[0].elements['encryptedcvv'].value = encryptField(cvv.value);
		 		return true;
	}
	 }
function nameoncardval1(){
	var nameoncardval = document.forms[0].elements['nameoncard1'];
	if(nameoncardval.value == ''){
		document.getElementById('nameoncard_error1').innerHTML='Please enter name on Card.';
		document.forms[0].elements['nameoncard1'].focus();
		return false;
	}
else{
		document.getElementById('nameoncard_error1').innerHTML='';
		document.forms[0].elements['nameoncard'].value=nameoncardval.value;
		return true;
	}
}
  function cardtypeval1(){
	var cardtype = document.forms[0].elements['card1'];
	if(cardtype.value == ''){
		document.getElementById('cardtype_error1').innerHTML='Please Select Your Card Type.';
		document.forms[0].elements['card1'].focus();
		return false;
	}
else{
		document.getElementById('cardtype_error1').innerHTML='';
		document.forms[0].elements['card'].value=cardtype.value;
		return true;
	}
	 }
function submitFormNetBanking(){
	var form = document.forms[0];
	if(validateNetBankingForm(form)) 	{
		form.action = '/zaakpay/post/';
		/*clearcardfields()*/;
		document.getElementById('loader2').style.display = 'block';
		document.getElementById('loader2').style.visibility = 'visible';
		document.getElementById('paynow2').style.display = 'none';
		 		document.getElementById('paynow2').style.visibility = 'hidden';
		 		document.getElementById('debitorcredit').value='netbanking';
		form.submit();
	}
}
function validateNetBankingForm(frm){
	if(!bankNameVal(frm)){
		return false;
	 	}
	return true;
}
function bankNameVal(frm){
	 	var bankName = frm.elements['bankid'];
	if(bankName.value == 'NULL'){
		document.getElementById('bankid_error').innerHTML='Please Select Your Bank.';
		document.forms[0].elements['bankid'].focus();
		return false;
	}
else{
		document.getElementById('bankid_error').innerHTML='';
		return true;
	}
	 }

function encryptField(cardvalue){
	 	 	var out = '';
	 	 	for (var i = 0;
i  <  cardvalue.length;
i++) {
	      out += (cardvalue.charAt(i).charCodeAt() + key.charAt(i%key.length).charCodeAt()) + ',';
	    }
   return out;
	 }
/* function clearsessionid(){
	document.forms[0].elements['sessionid'].value = '';
	document.forms[0].elements['sessionid'].value = '';
}
 function clearcardfields(){
	document.forms[0].elements['cvv'].value = 'xxx';
	document.forms[0].elements['cvv'].value = 'xxx';
	document.forms[0].elements['pan1'].value = 'xxxx';
	document.forms[0].elements['pan2'].value = 'xxxx';
	document.forms[0].elements['pan3'].value = 'xxxx';
	document.forms[0].elements['pan4'].value = 'xxxx';
	document.forms[0].elements['pan1'].value = 'xxxx';
	document.forms[0].elements['pan2'].value = 'xxxx';
	document.forms[0].elements['pan3'].value = 'xxxx';
	document.forms[0].elements['pan4'].value = 'xxxx';
	document.forms[0].elements['expiry_month'].value = 'mm';
	document.forms[0].elements['expiry_year'].value = 'yy';
	document.forms[0].elements['expiry_month'].value = 'mm';
	document.forms[0].elements['expiry_year'].value = 'yy';
	clearsessionid();
} */
function checkpan( part, next){
	
	if (document.getElementById(part).value.length == 4) 		{
			document.getElementById(next).focus();
		}
}

function submitMobi(){
	var form = document.forms[0];
		document.getElementById('loader3').style.display = 'block';
		document.getElementById('loader3').style.visibility = 'visible';
		document.getElementById('paynow3').style.display = 'none';
 		document.getElementById('paynow3').style.visibility = 'hidden';
				
document.getElementById('debitorcredit').value='wallet';
					
	form.submit();

}
