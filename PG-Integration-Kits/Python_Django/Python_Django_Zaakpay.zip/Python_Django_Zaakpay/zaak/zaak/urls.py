from django.conf.urls import patterns, include, url

# Uncomment the next two lines to enable the admin:
# from django.contrib import admin
# admin.autodiscover()

urlpatterns = patterns('',
    url(r'^zaakpay/$', 'zaakpay.views.index'),
    url(r'^zaakpay/posttozaakpay', 'zaakpay.views.posttozaakpay'),
    url(r'^zaakpay/response', 'zaakpay.views.response'),
    # Examples:
    # url(r'^$', 'zaak.views.home', name='home'),
    # url(r'^zaak/', include('zaak.foo.urls')),

    # Uncomment the admin/doc line below to enable admin documentation:
    # url(r'^admin/doc/', include('django.contrib.admindocs.urls')),

    # Uncomment the next line to enable the admin:
    # url(r'^admin/', include(admin.site.urls)),
)
