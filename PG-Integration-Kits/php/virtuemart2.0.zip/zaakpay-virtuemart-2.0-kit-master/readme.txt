
MODULE NAME : ZAAKPAY VIRTUEMART MODULE
------------------------------------------


SUPPORT
------------
Joomla version : 1.7.x , 2.x
Virtuemart version : 2.0


INSTALLATION
--------------

1. After the installation of virtuemart component 2.0, you can upload the plugin_zaakpay_pm_virtuemart_2.0.zip using extension manager in joomla.
2. Enable Zaakpay payment method in plugin manager.


CONFIGURATION
---------------

	- Login to Administrator Area - site administrator panel,
	- Select VirtueMart Store panel in the drop list,
	- Click on Payment Methods.
	- Click on New button on the right side to add the new payment method.
	- Click the Payment Method Information tab.
	- Give the Payment method name, and select YES to publish.
	- Choose the Zaakpay Payment Method in dropdown box.
	- Then Click on Save button to generate the configuration parameters.

	- Go to the Configuration tab.
	- Now you can fill the parameters listed in Configuration tab.
	- You should give the Zaakpay Merchant id, Secret key, Mode and description in the listed parameters on configuration tab. These parameters are Mandatory.
	- Then click Save & Close.
