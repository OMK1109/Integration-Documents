Instructions

1)	Copy the Zaakpay.php file to upload\admin\controller\payment\Zaakpay.php
2)	Copy the Zaakpay.php file to upload\admin\language\english\payment\ Zaakpay.php
3)	Copy the Zaakpay.tpl file to upload\admin\view\template\payment\ Zaakpay.tpl
4)	Copy the Zaakpay.php file to upload\catalog\controller\payment\ Zaakpay.php
5)	Copy the Zaakpay.php file to upload\catalog\language\english\common\ Zaakpay.php
6)	Copy the Zaakpay.php file to upload\catalog\language\english\payment\ Zaakpay.php
7)	Copy the Zaakpay.php file to upload\catalog\model\payment\ Zaakpay.php
8)	Copy the response.tpl file to upload\catalog\view\theme\default\template\common\response.tpl
9)	Copy the Zaakpay.tpl file to upload\catalog\view\theme\default\template\payment\ Zaakpay.tpl
10)	Enter your MerchantIdentifier , Secret Key and select the Mode from the Zaakpay Payment Method control panel & Enable it.
