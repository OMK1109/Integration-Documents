<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('ZAAKPAY_MERCHANT_ID', 'Merchant_Id');
define ('ZAAKPAY_SECRET_KEY', 'SecretKey');
define ('ZAAKPAY_VERIFIED_STATUS', 'C');
define ('ZAAKPAY_INVALID_STATUS', 'X');
define ('ZAAKPAY_PENDING_STATUS', 'P');
define ('ZAAKPAY_MODE', 'mode');
?>