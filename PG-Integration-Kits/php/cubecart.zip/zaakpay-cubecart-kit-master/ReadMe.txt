Instructions:

1)	Copy the folder Zaakpay to cubecart\modules\gateway\Zaakpay
 
2)	In Admin panel Enter your Merchant Identifier , Secret Key , IP address and select the Mode from the Zaakpay Payment Method control panel & Enable it.

3)	And you're ready 
