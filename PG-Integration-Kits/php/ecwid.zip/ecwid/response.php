<?php

session_start();
require_once('config.php');
require_once('ecwid-config.php');
require_once('checksum.php');

$x_response_code = '';
$x_response_reason_code = '';

$secret = $secretKey;

$all = Checksum::getAllParams();

if(Checksum::verifyChecksum($_POST['checksum'],$all,$secret))
{
	if($_REQUEST['responseCode'] == 100)
	{
	    $x_response_code = '1';
	    $x_response_reason_code = '1';
	}
	else if($_REQUEST['responseCode'] == 107)
	{
	    $x_response_code = '3';
	    $x_response_reason_code = '5';
	}
	else if($_REQUEST['responseCode'] == 180)
	{
		$x_response_code = '3';
	    $x_response_reason_code = '66';
	}
	else if($_REQUEST['responseCode'] == 102)
	{
        $x_response_code = '2';
	    $x_response_reason_code = '2';   
	}
	else if($_REQUEST['responseCode'] == 103)
	{
        $x_response_code = '3';
	    $x_response_reason_code = '66';
	}
	else
	{
        $x_response_code = '2';
	    $x_response_reason_code = '2';
	}
}
else
{
	$x_response_code = '3';
	$x_response_reason_code = '66';
}

$x_trans_id = $_REQUEST['orderId'];

$x_invoice_num = $_REQUEST['orderId'];

$x_amount = $_SESSION['amount'];

$string = $hash_value.$x_login.$x_trans_id.$x_amount;
$x_MD5_Hash = md5($string);
$datatopost = array (
"x_response_code" => $x_response_code,
"x_response_reason_code" => $x_response_reason_code,
"x_trans_id" => $x_trans_id,
"x_invoice_num" => $x_invoice_num,
"x_amount" => $x_amount,
"x_MD5_Hash" => $x_MD5_Hash,
);

$url = 'http://app.ecwid.com/authorizenet/'.$storeId;
$ch = curl_init($url);
	 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $datatopost);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	 
$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>
