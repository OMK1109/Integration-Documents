<?php
// -------------------------------------------------------------------------
// Ecwid Configuration file.  Ensure that only the user that PHP runs under can
// access this file on your web server disk.
// -------------------------------------------------------------------------

// These variables are needed for your script that returns data to Ecwid to complete the order

// Replace X_LOGIN with your API Login ID code from the Ecwid Authorize.Net SIM account details page.
$x_login =  'X_LOGIN';

// Replace MD5_HASH_VALUE  with your MD5 Hash Value code from the Ecwid Authorize.Net SIM account details page.
$hash_value =  'MD5_HASH_VALUE';

?>
