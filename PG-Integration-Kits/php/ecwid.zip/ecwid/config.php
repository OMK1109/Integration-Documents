<?php
// -------------------------------------------------------------------------
// Configuration file.  Ensure that only the user that PHP runs under can
// access this file on your web server disk.
// -------------------------------------------------------------------------

// Replace _YOUR_SECRET_KEY_ with your secret key from the Zaakpay web site.
$secretKey =  '_YOUR_SECRET_KEY';

// Please give the path of response.php file on your server.
$return_link_url = 'http://localhost/ecwid/response.php';

// Change _Merchant_id_ to your Merchant ID
$merchantId = '_Merchant_id_';

// Change _Store_id_ to your Store ID
$storeId = '_Store_id_';

?>