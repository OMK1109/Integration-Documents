<?php 
session_start();
$_SESSION['amount'] = $_REQUEST['x_amount'];

require_once 'config.php';
?>
<!DOCTYPE html>
<html>
<body>
<form action="posttozaakpay.php" method="post">
<input type="hidden" name="merchantIdentifier" value="<?php echo $merchantId; ?>" />
<input type="hidden" id="orderId" name="orderId" value="<?php echo $_REQUEST['x_invoice_num']; ?>" />
<input type="hidden" name="returnUrl" value="<?php echo $return_link_url; ?>"/>
<input type="hidden" name="buyerEmail" value="<?php echo $_REQUEST['x_email']; ?>"  /> 
<input type="hidden" name="buyerFirstName" value="<?php echo $_REQUEST['x_first_name']; ?>" /> 
<input type="hidden" name="buyerLastName" value="<?php echo $_REQUEST['x_last_name']; ?>" /> 
<input type="hidden" name="buyerAddress" value="<?php echo $_REQUEST['x_address']; ?>" /> 
<input type="hidden" name="buyerCity" value="<?php echo $_REQUEST['x_city']; ?>" />
<input type="hidden" name="buyerState" value="<?php echo $_REQUEST['x_state']; ?>" />
<input type="hidden" name="buyerCountry" value="<?php echo $_REQUEST['x_country']; ?>" /> 
<input type="hidden" name="buyerPincode" value="<?php echo $_REQUEST['x_zip']; ?>" /> 
<input type="hidden" name="buyerPhoneNumber" value="<?php echo $_REQUEST['x_phone']; ?>" />
<input type="hidden" name="txnType" value="1" />
<input type="hidden" name="zpPayOption" value="1" />
<input type="hidden" name="mode" value="0" /> 
<input type="hidden" name="currency" value="INR" />
<input type="hidden" name="amount" value="<?php echo (int)(((float)$_REQUEST['x_amount'])*100); ?>" /> 
<input type="hidden" name="merchantIpAddress" value="127.0.0.1" />
<input type="hidden" name="productDescription" value="<?php echo $_REQUEST['x_description']; ?>" /> 
<input type="hidden" name="purpose" value="1" />
<input type="hidden" name="txnDate" id="txnDate" value="<?php echo date('Y-m-d'); ?>" />
</form>
<script type="text/javascript">
document.forms[0].submit();
</script>
</body>
</html>