<?php
// Heading
$_['heading_title']   = 'Zaakpay';

// Entry
$_['text_payment']		            	   = 'Payment';
$_['entry_status']                         = 'Status:';
$_['text_success']      				   = 'Success: You have modified Zaakpay payment module!';
$_['text_Zaakpay']	            		   = '<a onclick="window.open(\'http://www.zaakpay.com\');"><img src="view/image/payment/Zaakpay.gif" alt="Zaakpay" title="Zaakpay" style="border: 1px solid #EEEEEE;" height=40 /></a>';

$_['merchantIdentifier']		 		   = 'Merchant Identifier:';
$_['secret_key']					 	   = 'Secret Key: ';
$_['mode']						   		   = 'Test Mode: ';
$_['log']     							   = 'Do you want to log:';
$_['entry_geo_zone']   					   = 'Geo Zone:';
$_['test_enabled']   					   = 'on';
$_['test_disabled']   					   = 'off';
// Error
$_['error_permission']                     = 'Warning: You do not have permission to modify payment Zaakpay!';
$_['error_merchantid']				= 'Zaakpay Merchant Identifier required!';
$_['error_secret_key'] = 'Zaakpay Secret Key Required!';
?>
