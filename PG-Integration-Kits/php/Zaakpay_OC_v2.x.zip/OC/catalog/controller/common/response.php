<?php
class ControllerCommonResponse extends Controller { 

	public function index() { 
		$this->load->language('common/Zaakpay');
		$data['button_confirm'] = $this->language->get('button_confirm');
		$data['button_continue'] = $this->language->get('button_continue');
		$data['heading_title'] = $this->language->get('heading_title');
		$data['continue'] = HTTP_SERVER . 'index.php?route=common/home';
		$secret_key = $this->config->get('Zaakpay_secret_key');
	
		if(isset($_REQUEST['orderId'])) {
			$response = array();
			$orderId=$_REQUEST['orderId'];
			$response['orderId']=$orderId;
			$response['responseCode']=$_REQUEST['responseCode'];
			$response['responseDescription']=$_REQUEST['responseDescription'];
			$response['amount']=$_REQUEST['amount'];
			$response['paymentMethod']=$_REQUEST['paymentMethod'];
			$response['cardhashid']=$_REQUEST['cardhashid'];
			$response['checksum']=$_REQUEST['checksum'];
			$data['response']=$response;
			
			if($this->config->get('Zaakpay_log') == "on") {
				error_log('orderId::'.$response['orderId']);
				error_log('responseCode::'.$response['responseCode']. ' for orderid '.$response['orderId']);
				error_log('responseDescription::'.$response['responseDescription']. ' for orderid '.$response['orderId']);
				error_log('amount::'.$response['amount']. ' for orderid '.$response['orderId']);
				error_log('paymentMethod::'.$response['paymentMethod']. ' for orderid '.$response['orderId']);
				error_log('cardhashid::'.$response['cardhashid']. ' for orderid '.$response['orderId']);
			}
			
			$all = '';
			foreach($response as $key => $value){
				if($key != 'checksum'){
					$all .= "'";
					$all .= $value;
					$all .= "'";
				}
			}
			
			$bool = 0;
			$cal_checksum = hash_hmac('sha256', $all , $secret_key);
			if($cal_checksum == $response['checksum'])
				$bool = 1;
	
			if($this->config->get('Zaakpay_log') == "on") {	
				error_log("AllParams in response : ".$all);
				error_log('Calculated checksum: '.$cal_checksum);
				error_log("Checksum received in response: ".$response['checksum']);
			}
			
			$this->load->model('checkout/order');
			$this->layout   = 'common/layout';
			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['footer'] = $this->load->controller('common/footer');
			
			//if checksum is verified
			if($bool==1) {
				$order_info = $this->model_checkout_order->getOrder($response['orderId']);
				//if transaction is successful
				if($response['responseCode']=='100') {
					if (isset($this->session->data['order_id'])) {
						$this->cart->clear();
						unset($this->session->data['shipping_method']);
						unset($this->session->data['shipping_methods']);
						unset($this->session->data['payment_method']);
						unset($this->session->data['payment_methods']);
						unset($this->session->data['guest']);
						unset($this->session->data['comment']);
						unset($this->session->data['order_id']);	
						unset($this->session->data['coupon']);
					}
					
					if($order_info){
						$this->model_checkout_order->addOrderHistory($order_info['order_id'], '5');
					}
					$data['responseMsg']='<div style="width:965px;float:middle;padding:5px;margin:10px 0px;background-color:#66CCFF;color:#000000;-webkit-border-radius:5px;-moz-border-radius:5px;-o-border-radius:5px;border-radius:5px;" class="box-box"><p><center>Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.</center></p></div><br/><br/>';
				} else {
					$this->model_checkout_order->addOrderHistory($order_info['order_id'], '10');
					$data['responseMsg']='<div style="width:965px;float:middle;padding:5px;margin:10px 0px;background-color:#66CCFF;color:#000000;-webkit-border-radius:5px;-moz-border-radius:5px;-o-border-radius:5px;border-radius:5px;" class="box-box"><p><center>Thank you for shopping with us. However, the transaction has been declined!!.</center><p/></div><br/><br/><h2> ';
				}
			} else {
				$this->model_checkout_order->addOrderHistory($order_info['order_id'], '10');
				$data['responseMsg']='<div style="width:965px;float:middle;padding:5px;margin:10px 0px;background-color:#66CCFF;color:#000000;-webkit-border-radius:5px;-moz-border-radius:5px;-o-border-radius:5px;border-radius:5px;" class="box-box"><p><center>Security Error. Illegal access detected.</center><p/></div><br/><br/><h2> ';
			}
			
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/common/response.tpl')) {
				$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/common/response.tpl', $data));
			} else {
				$this->response->setOutput($this->load->view('default/template/common/response.tpl', $data));
			}
		}
	}
}
?>