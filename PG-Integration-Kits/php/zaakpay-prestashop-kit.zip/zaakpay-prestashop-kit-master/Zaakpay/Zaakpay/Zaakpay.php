<?php



if (!defined('_CAN_LOAD_FILES_'))

	exit;



class Zaakpay extends PaymentModule

{

	private	$_html = '';

	private $_postErrors = array();

	private $_responseReasonText = null;



	public function __construct(){

		$this->name = 'Zaakpay';

		$this->tab = 'Payment';

		$this->version = '0.1';

		$this->author = '';



        parent::__construct();

		$this->idOrderState = Configuration::get('ZAAKPAY_ID_ORDER_STATE');



        /* The parent construct is required for translations */

		$this->page = basename(__FILE__, '.php');

        $this->displayName = $this->l('Zaakpay');



        $this->description = $this->l('Module for accepting payments by Zaakpay');

	}



	public function getZaakpayUrl(){

			return 'https://api.zaakpay.com/transact?v=3';

	}



	public function install(){

		if (parent::install()){

			$sid = $this->getOrderState();

			$fid =$this->getOrderState()+1;

			Configuration::updateValue('ZAAKPAY_MERCHANT_ID', '');

			Configuration::updateValue('ZAAKPAY_SECRET_KEY', '');

			Configuration::updateValue('ZAAKPAY_MODE', '');

			Configuration::updateValue('LOG', '');

			Configuration::updateValue('ZAAKPAY_ID_ORDER_SUCCESS',$sid);

			Configuration::updateValue('ZAAKPAY_ID_ORDER_FAILED',$fid);			

			

			$this->registerHook('payment');

			$this->registerHook('ShoppingCartExtra');

			

			Db::getInstance()->Execute

			('

				INSERT INTO `' . _DB_PREFIX_ . 'order_state`

			( `id_order_state`,`invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`)

				VALUES

			('.$sid.',0, 0, \'#33FF99\', 0, 0,0);

			');

			

			Db::getInstance()->Execute

				('

					INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` 

				(`id_order_state`, `id_lang`, `name`, `template`) 

					VALUES 

				('.$sid.', 1, \'Payment accepted\', \'payment\')');				

			

			Db::getInstance()->Execute

			('

				INSERT INTO `' . _DB_PREFIX_ . 'order_state`

			( `id_order_state`,`invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`)

				VALUES

			('.$fid.',0, 0, \'#33FF99\', 0, 0,0);

			');

			

			Db::getInstance()->Execute

				('

					INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` 

				(`id_order_state`, `id_lang`, `name`, `template`) 

					VALUES 

				('.$fid.', 1, \'Payment Failed\', \'payment\')');	

			

			return true;

		}

		else {

			return false;

		}

	}



	public function uninstall(){

		Db::getInstance()->Execute

				('

					DELETE FROM `' . _DB_PREFIX_ . 'order_state` 

					 WHERE id_order_state = '.Configuration::get('ZAAKPAY_ID_ORDER_SUCCESS'));

		

		Db::getInstance()->Execute

				('

					DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` 

					 WHERE id_order_state = '.Configuration::get('ZAAKPAY_ID_ORDER_SUCCESS').' and id_lang = 1' );



		Db::getInstance()->Execute

				('

					DELETE FROM `' . _DB_PREFIX_ . 'order_state` 

					 WHERE id_order_state = '.Configuration::get('ZAAKPAY_ID_ORDER_FAILED'));

				

		Db::getInstance()->Execute

				('

					DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` 

					 WHERE id_order_state = '.Configuration::get('ZAAKPAY_ID_ORDER_FAILED').' and id_lang = 1');

				

		

		if (!Configuration::deleteByName('ZAAKPAY_MERCHANT_ID') OR

			!Configuration::deleteByName('ZAAKPAY_SECRET_KEY') OR

			!Configuration::deleteByName('ZAAKPAY_MODE') OR

			!Configuration::deleteByName('LOG') OR

			!Configuration::deleteByName('ZAAKPAY_ID_ORDER_SUCCESS') OR

			!Configuration::deleteByName('ZAAKPAY_ID_ORDER_FAILED') OR

			!parent::uninstall())

			return false;

		return true;

	}

	public function getOrderState(){

		$id=Db::getInstance()->getRow

		('

			SELECT max(id_order_state) as id FROM `' . _DB_PREFIX_ . 'order_state`

		');



		$id['id']++;

		return $id['id'];

	}

	public function getContent(){

		$this->_html = '<h2>'.$this->displayName.'</h2>';

		if (isset($_POST['submitZaakpay'])){

			if (empty($_POST['merchant_id']))

				$this->_postErrors[] = $this->l('Please Enter your Merchant ID.');

			if (empty($_POST['secret_key']))

				$this->_postErrors[] = $this->l('Please Enter your Secret Key.');

			if (empty($_POST['mode']))

				$this->_postErrors[] = $this->l('Please Select the Mode, you want to work on .');

			

			if (!sizeof($this->_postErrors)){

				Configuration::updateValue('ZAAKPAY_MERCHANT_ID', $_POST['merchant_id']);

				Configuration::updateValue('ZAAKPAY_SECRET_KEY', $_POST['secret_key']);

				Configuration::updateValue('ZAAKPAY_MODE', $_POST['mode']);

				Configuration::updateValue('LOG', $_POST['log']);

				$this->displayConf();

			}

			else{

				$this->displayErrors();

			}

		

		}

		$this->displayZaakpay();

		$this->displayFormSettings();

		return $this->_html;

	}



	public function displayConf()

	{

		$this->_html .= '

		<div class="conf confirm">

			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />

			'.$this->l('Settings updated').'

		</div>';

	}



	public function displayErrors(){

		$nbErrors = sizeof($this->_postErrors);

		$this->_html .= '

		<div class="alert error">

			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>

			<ol>';

		foreach ($this->_postErrors AS $error)

			$this->_html .= '<li>'.$error.'</li>';

		$this->_html .= '

			</ol>

		</div>';

	}





	public function displayZaakpay(){

		$this->_html .= '

		<div style="float: right; width: 440px; height: 150px; border: dashed 1px #666; padding: 8px; margin-left: 12px;">

			<h2>'.$this->l('Open your Zaakpay Account').'</h2>

			<div style="clear: both;"></div></b><br />

			<p>'.$this->l('Click on the Zaakpay Logo Below to register or edit your Zaakpay Account').'</p>

			<p style="text-align: center;"><a href="https://www.zaakpay.com/"><img src="../modules/Zaakpay/logo.gif" alt="Zaakpay" style="margin-top: 12px;" /></a></p>

			<div style="clear: right;"></div>

		</div>

		<b></b><br />

		<b>'.$this->l('This module allows you to accept payments by Zaakpay.').'</b><br /><br /><br />

		'.$this->l('If the client chooses this payment mode, your Zaakpay account will be automatically credited.').'<br /><br />

		'.$this->l('You need to configure your Zaakpay account first before using this module.').'

		<div style="clear:both;">&nbsp;</div>';

	}



	public function displayFormSettings(){

	

		$test = '';

		$live = '';

		$on = '';

		$off = '';

		$mode = Configuration::get('ZAAKPAY_MODE');

		$id = Configuration::get('ZAAKPAY_MERCHANT_ID');

		$key = Configuration::get('ZAAKPAY_SECRET_KEY');

		$z_log = Configuration::get('LOG');

		if(!empty($id)){

			$merchant_id = $id;

		}

		else{

			$merchant_id = '';

		}

		

		if(!empty($key)){

			$secret_key = $key;

		}

		else{

			$secret_key = '';

		}

		

		if(!empty($mode)){

			if($mode=='TEST'){

				$test = "selected='selected'";

				$live = '';

			}

			if($mode=='LIVE'){

				$live = "selected='selected'";

				$test = '';

			}

		}

		else{

			$live = '';

			$test = '';

		}

		

		if(!empty($z_log)){

			if($z_log=='ON'){

				$on = "checked='checked'";

				$off = '';

			}

			if($z_log=='OFF'){

				$off = "checked='checked'";

				$on = '';

			}

		}

		else{

			$off = '';

			$on = "checked='checked'";

		}



		$this->_html .= '

		<form action="'.$_SERVER['REQUEST_URI'].'" method="post">

			<fieldset>

			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configuration Settings').'</legend>

				<table border="0" width="500" cellpadding="0" cellspacing="0" id="form">

					<tr><td colspan="2">'.$this->l('Please specify the Merchant ID and Secret Key provided by Zaakpay.').'<br /><br /></td></tr>

					<tr><td width="130" style="height: 25px;">'.$this->l('Zaakpay Merchant ID').'</td><td><input type="text" name="merchant_id" value="'.$merchant_id.'" style="width: 170px;" /></td></tr>

					<tr>

						<td width="130" style="height: 25px;">'.$this->l('Zaakpay Secret Key').'</td>

						<td><input type="text" name="secret_key" value="'.$secret_key.'" style="width: 170px;" /></td>

					</tr>

					<tr>

						<td width="130" style="height: 25px;">'.$this->l('Zaakpay Mode').'</td>

						<td>

							<select name="mode" style="width: 110px;">

								<option value="">-Select-</option>

								<option value="TEST" '.$test.'>Sandbox(Test)</option>

								<option value="LIVE" '.$live.'>Live</option>

							</select>

						</td>

					</tr>

					<tr><td colspan="2"><p class="hint clear" style="display: block; width: 350px;">'.$this->l('Select the Mode you want to work on.').'</p></td></tr>

					<tr> </tr>

				    <tr>

						<td width="200" style="height: 25px; padding-top:20px;">'.$this->l('Log ( Logging Parameters passing through Zaakpay )').'</td>

						<td>

							<input type="radio"  style="width: 110px;" name="log" value="ON" '.$on.' /> On </td><br /><br />

						<td> <input type="radio" name="log" value="OFF" '.$off.' /> Off </td></tr><br /><br />

					<!-- <tr><td colspan="2"><p style="display: block; width: 350px;">'.$this->l('( Logging Parameters passing through Zaakpay )').'</p></td></tr> -->

					<tr><td colspan="2" align="center"><br /><input class="button" name="submitZaakpay" value="'.$this->l('Update settings').'" type="submit" /></td></tr>

				</table>

			</fieldset>

		</form>

		';

	}



	public function hookPayment($params){

		global $smarty,$cart;		

		//echo "<pre>";print_r($cart);echo "</pre>";

		require(dirname(__FILE__).'/checksum.php');

				

		$countryarray=array("IN"=>"IND","DE"=>"DEU","BR"=>"BRA","DE"=>"DEU","AT"=>"AUT","BE"=>"BEL","CA"=>"CAN","CN"=>"CHN","ES"=>"ESP","FI"=>"FIN","FR"=>"FRA","GR"=>"GRC","IT"=>"ITA","JP"=>"JPN","LU"=>"LUX","NL"=>"NLD","PL"=>"POL","PT"=>"PRT","CZ"=>"CZE","GB"=>"GBR","SE"=>"SWE","CH"=>"CHE","DK"=>"DNK","US"=>"USA","HK"=>"HKG","NO"=>"NOR","AU"=>"AUS","SG"=>"SGP","IE"=>"IRL","NZ"=>"NZL","KR"=>"KOR","IL"=>"ISR","ZA"=>"ZAF","NG"=>"NGA","CI"=>"CIV","TG"=>"TGO","BO"=>"BOL","MU"=>"MUS","RO"=>"ROU","SK"=>"SVK","DZ"=>"DZA","AS"=>"ASM","AD"=>"AND","AO"=>"AGO","AI"=>"AIA","AG"=>"ATG","AR"=>"ARG","AM"=>"ARM","AW"=>"ARW","AZ"=>"AZE","BS"=>"BHS","BH"=>"BHR","BD"=>"BGD","BB"=>"BRB","BY"=>"BLR","BZ"=>"BLZ","BJ"=>"BEN","BM"=>"BMU","BT"=>"BTN","BW"=>"BWA","BN"=>"BRN","BF"=>"BFA","MM"=>"MMR","BI"=>"BDI","KH"=>"KHM","CM"=>"CMR","CV"=>"CPV","CF"=>"CAF","TD"=>"TCD","CL"=>"CHL","CO"=>"COL","KM"=>"COM","CD"=>"COD","CG"=>"COG","CR"=>"CRI","HR"=>"HRV","CU"=>"CUB","CY"=>"CYP","DJ"=>"DJI","DM"=>"DMA","DO"=>"DOM","TL"=>"TLS","EC"=>"ECU","EG"=>"EGY","SV"=>"SLV","GQ"=>"GNQ","ER"=>"ERI","EE"=>"EST","ET"=>"ETH","FK"=>"FLK","FO"=>"FRO","FJ"=>"FJI","GA"=>"GAB","GM"=>"GMB","GE"=>"GEO","GH"=>"GHA","GD"=>"GRD","GL"=>"GRL","GI"=>"GIB","GP"=>"GLP","GU"=>"GUM","GT"=>"GTM","GG"=>"GGY","GN"=>"GIN","GP"=>"GLP","GW"=>"GNB","GY"=>"GUY","HT"=>"HTI","HM"=>"HMD","VA"=>"VAT","HN"=>"HND","IS"=>"ISL","ID"=>"IDN","IR"=>"IRN","IQ"=>"IRQ","IM"=>"IMN","JM"=>"JAM","JE"=>"JEY","JO"=>"JOR","KZ"=>"KAZ","KE"=>"KEN","KI"=>"KIR","KP"=>"PRK","KW"=>"KWT","KG"=>"KGZ","LA"=>"LAO","LV"=>"LVA","LB"=>"LBN","LS"=>"LSO","LR"=>"LBR","LS"=>"LSO","LR"=>"LBR","LY"=>"LBY","LI"=>"LIE","LT"=>"LTU","MO"=>"MAC","MK"=>"MKD","MG"=>"MDG","MW"=>"MWI","MY"=>"MYS","MV"=>"MDV","ML"=>"MLI","MT"=>"MLT","MH"=>"MHL","MQ"=>"MTQ","MR"=>"MRT","HU"=>"HUN","YT"=>"MYT","MX"=>"MEX","FM"=>"FSM","MD"=>"MDA","MC"=>"MCO","MN"=>"MNG","ME"=>"MNE","MS"=>"MSR","MA"=>"MAR","MZ"=>"MOZ","NA"=>"NAM","NR"=>"NRU","NP"=>"NPL","AN"=>"ANT","NC"=>"NCL","NI"=>"NIC","NE"=>"NER","NU"=>"NIU","NF"=>"NFK","MP"=>"MNP","OM"=>"OMN","PK"=>"PAK","PW"=>"PLW","PS"=>"PSE","PA"=>"PAN","PG"=>"PNG","PY"=>"PRY","PE"=>"PER","PH"=>"PHL","PN"=>"PCN","PR"=>"PRI","QA"=>"QAT","RE"=>"REU","RU"=>"RUS","RW"=>"RWA","BL"=>"BLM","KN"=>"KNA","LC"=>"LCA","MF"=>"MAF","PM"=>"SPM","VC"=>"VCT","WS"=>"WSM", "SM"=>"SMR", "ST"=>"STP","SA"=>"SAU", "SN"=>"SEN","RS"=>"SRB","SC"=>"SYC", "SL"=>"SLE","SI"=>"SVN","SB"=>"SLB","SO"=>"SOM","GS"=>"SGS","LK"=>"LKA","SD"=>"SDN","SR"=>"SUR","SJ"=>"SJM","SZ"=>"SWZ","SY"=>"SYR","TW"=>"TWN","TJ"=>"TJK","TZ"=>"TZA","TH"=>"THA","TK"=>"TKL","TO"=>"TON","TT"=>"TTO","TN"=>"TUN","TR"=>"TUR","TM"=>"TKM","TC"=>"TCA","TV"=>"TUV","UG"=>"UGA","UA"=>"UKR","AE"=>"ARE","UY"=>"URY","UZ"=>"UZB","VU"=>"VUT","VE"=>"VEN","VN"=>"VNM","VG"=>"VGB","VI"=>"VIR","WF"=>"WLF","EH"=>"ESH","YE"=>"YEM","ZM"=>"ZMB","ZW"=>"ZWE","AL"=>"ALB","AF"=>"AFG","AQ"=>"ATA","BA"=>"BIH","BV"=>"BVT","IO"=>"IOT","BG"=>"BGR","KY"=>"CYM","CX"=>"CXR","CC"=>"CCK","CK"=>"COK","GF"=>"GUF","PF"=>"PYF","TF"=>"ATF","AX"=>"ALA");

		$bill_address = new Address(intval($params['cart']->id_address_invoice));

		$ship_address = new Address(intval($params['cart']->id_address_delivery));		

		

		$customer = new Customer(intval($params['cart']->id_customer));

		$merchant_id= Configuration::get('ZAAKPAY_MERCHANT_ID');

		$secret_key = Configuration::get('ZAAKPAY_SECRET_KEY');

		$log = Configuration::get('LOG');

		$mode = Configuration::get('ZAAKPAY_MODE');

		$mod = $mode;

		if($mod == "TEST")

		$mode = 0;

		else

		$mode = 1;

		

		$id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));

		//$currency = new Currency(intval($id_currency));		

		$currency = new Currency((int)($id_currency));

		$iso_currency = $currency->iso_code;

		//$currency = $this->getCurrency();

		$first_name = $bill_address->firstname;

		$last_name = $bill_address->lastname;

		//$name = $first_name." ".$last_name;

		$address1 = $bill_address->address1;

		$address2 = $bill_address->address2;

		$address = $address1." ".$address2;		

		$city = $bill_address->city;		

		$countryiso2=new Country(intval($bill_address->id_country));

		$countryiso2->iso_code = $countryarray[$countryiso2->iso_code];

		$country = $countryiso2->iso_code;

		$state_obj = new State($bill_address->id_state);

		$state = utf8_decode ($state_obj->name);

		//$phone = $bill_address->phone_mobile;

		if($bill_address->phone != null)

		{

		$phone = $bill_address->phone;

		}

		else

		{

		$phone = $bill_address->phone_mobile;

		}

		$postal_code = $bill_address->postcode;

		$email = $customer->email;

		

		$ship_first_name = $ship_address->firstname;

		$ship_last_name = $ship_address->lastname;

		//$ship_name = $ship_first_name." ".$ship_last_name;

		$ship_address1 = $ship_address->address1;

		$ship_address2 = $ship_address->address2;

		$ship_addr = $ship_address1." ".$ship_address2;		

		$ship_city = $ship_address->city;		

		$ship_countryiso2=new Country(intval($ship_address->id_country));

		$ship_countryiso2->iso_code = $countryarray[$ship_countryiso2->iso_code];

		$ship_country = $ship_countryiso2->iso_code;

		$ship_state_obj = new State($ship_address->id_state);

		$ship_state = utf8_decode ($state_obj->name);

		//$ship_phone = $ship_address->phone;

		if($ship_address->phone != null)

		{

		$ship_phone = $ship_address->phone;

		}

		else

		{

		$ship_phone = $ship_address->phone_mobile;

		}

		$ship_postal_code = $ship_address->postcode;

		



		if (!Validate::isLoadedObject($bill_address) OR !Validate::isLoadedObject($customer))

			return $this->l('Zaakpay error: (invalid address or customer)');

			

			$products = $params['cart']->getProducts();



		foreach ($products as $key => $product)

		{

			$products[$key]['name'] = str_replace('"', '\'', $product['name']);

			if (isset($product['attributes']))

				$products[$key]['attributes'] = str_replace('"', '\'', $product['attributes']);

			$products[$key]['name'] = htmlentities(utf8_decode($product['name']));

			$products[$key]['payfastAmount'] = number_format(Tools::convertPrice($product['price_wt'], $currency), 2, '.', '');

		}

		

		

		$amount = 100 * ($cart->getOrderTotal(true,Cart::BOTH));	// Should be in Paisa

		$ref_no = intval($cart->id);

		$return_url = 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/'.$this->name.'/response.php';

		$date = date('Y-m-d');

			

		$post_variables = Array(

		    "merchantIdentifier" => $merchant_id, 

		    "orderId" => intval($params['cart']->id),

			"returnUrl" => $return_url,

			"buyerEmail" => $email,

			"buyerFirstName" => $first_name,

			"buyerLastName" => $last_name,

			"buyerAddress" => $address,

			"buyerCity" => $city,

			"buyerState" => $state,

			"buyerCountry" => $country,

			"buyerPincode" =>  $postal_code,

			"buyerPhoneNumber" => $phone,

			"txnType" => 1,

			"zpPayOption" => 1,

			"mode" => $mode,

			"currency" => $iso_currency,

			"amount" => $amount,	

			"merchantIpAddress" => "127.0.0.1",  		//Merchant Ip Address

			"purpose" => 1,

			"productDescription" => $product['name'],	//"Zaakpay subscription fee",

		    "shipToAddress" => $ship_addr,	

			"shipToCity" => $ship_city,			

			"shipToState" => $ship_state,

			"shipToCountry" => $ship_country,

		    "shipToPincode" => $ship_postal_code,

			"shipToPhoneNumber" => $ship_phone,

			"shipToFirstname" => $ship_first_name,

			"shipToLastname" => $ship_last_name,

			"txnDate" => $date,

						

		);

		

		$s = new Checksum();

		$all = '';

		foreach($post_variables as $name => $value)	{

			if($name != 'checksum') {

				$all .= "'";

				if ($name == 'returnUrl') {

					$all .= $s->sanitizedURL($value);

				} else {				

					

					$all .= $s->sanitizedParam($value);

				}

				$all .= "'";

			}

		}

		if($log == "ON") {

		error_log("All Params(Parameters Posting to Zaakpay) : " .$all);

		//error_log("Zaakpay Secret Key : " .$secret_key);

		}



		$checksum = $s->calculateChecksum($secret_key,$all);

		

		$smarty->assign(array(

            

			'merchant_id' => $merchant_id,

			'firstname'=>$s->sanitizedParam($first_name),

			'lastname'=>$s->sanitizedParam($last_name),

			'address' => $s->sanitizedParam($address),

			'city' => $s->sanitizedParam($city),

			'state'	=> $s->sanitizedParam($state),

			'postal_code' => $s->sanitizedParam($postal_code),

			'country' => $s->sanitizedParam($country),

			'email' => $s->sanitizedParam($email),

			'phone' => $s->sanitizedParam($phone),

			'ship_first_name'=>$s->sanitizedParam($ship_first_name),

			'ship_last_name'=>$s->sanitizedParam($ship_last_name),

			'ship_address' => $s->sanitizedParam($ship_addr),

			'ship_city' => $s->sanitizedParam($ship_city),

			'ship_state'	=> $s->sanitizedParam($ship_state),

			'ship_postal_code' => $s->sanitizedParam($ship_postal_code),

			'ship_country' => $s->sanitizedParam($ship_country),

			'ship_phone' => $s->sanitizedParam($ship_phone),

			'mode'	=> $mode,

			'return_url'=> $s->sanitizedURL($return_url),

			'ZaakpayUrl' => $this->getZaakpayUrl(),

			'date' => $date,

			'currency' => $iso_currency,

			'prod' => $s->sanitizedParam($product['name']),

			'amount' => $amount,			

			//'amount' =>  $cart->getOrderTotal(true, Cart::BOTH),			

			'total' => number_format(Tools::convertPrice($params['cart']->getOrderTotal(true, 3), $currency), 2, '.', ''),

			'id_cart' => intval($params['cart']->id),

			'customer' => $customer,

			'cartID' => $ref_no,

			//'return_url' =>$return_url,

			'checksum' => $checksum,

			'this_path' => $this->_path

            //'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://').htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/'.$this->name.'/'

        ));

        



        return $this->display(__FILE__, 'Zaakpay.tpl');

    }







	

	/**

	 * Used outside of the payment hook to populate smarty vars

	 *

	 */

    public function populatePaymentVars()

    {

		global $smarty, $cart, $cookie;



		$address = new Address(intval($cart->id_address_invoice));

		$addressShip = new Address(intval($cart->id_address_delivery));

		$state = new State(intval($address->id_state));

		$address->state = $state->name;

		$state = new State(intval($addressShip->id_state));

		$addressShip->state = $state->name;

		$customer = new Customer(intval($cookie->id_customer));

		$merchant_id = Configuration::get('ZAAKPAY_MERCHANT_ID');

		$secret_key = Configuration::get('ZAAKPAY_SECRET_KEY');

		$mode = Configuration::get('ZAAKPAY_MODE');

		$id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));

		$this->currency = new Currency(intval($id_currency));

		$this->products = $cart->getProducts();





		foreach ($this->products as $key => $product)

		{

			$this->products[$key]['name'] = str_replace('"', '\'', $product['name']);

			if (isset($product['attributes']))

				$this->products[$key]['attributes'] = str_replace('"', '\'', $product['attributes']);

			$this->products[$key]['name'] = htmlentities(utf8_decode($product['name']));

			

			$this->products[$key]['ZaakpayAmount'] = number_format(Tools::convertPrice($product['price_wt'], $this->currency), 2, '.', '');

		}

		

		$smarty->assign(array(

			'ZaakpayUrl' => $this->getZaakpayUrl()

		));



    }



	

    public function setOrder($order_id,$res_code,$res_desc,$checksum_recv,$all1)

    {
#echo "inside setOrder";
    	global $smarty, $cart, $cookie;

		#require(dirname(__FILE__).'/checksum.php');

		

		$id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));

		$secret_key = Configuration::get('ZAAKPAY_SECRET_KEY');	 

//print_r($secret_key);

		

		#$check = new Checksum();

		$bool = 0;

		$all = $all1;
#echo "before calculatechecksum";
$hash = hash_hmac('sha256', $all1 , $secret_key);
		$chec = $hash;
		#$chec = $s->calculateChecksum($secret_key,$all1);
#echo "after checksum";


		$bool = 0;
		if($chec == $checksum_recv)	{
			$bool = 1;
		}

		#$bool = $s->verifyChecksum($checksum_recv, $all, $secret_key);

		$cartID=$order_id;

		$cart = new Cart($cartID);



		if($bool == 1)

		{

			if($res_code == 100)

			{ 

				$responseMsg="Your Order has Been Processed";

				$status=Configuration::get('ZAAKPAY_ID_ORDER_SUCCESS');

					

			}

			else

			{

				$responseMsg="Transaction Failed, Retry ..!";

				$status=Configuration::get('ZAAKPAY_ID_ORDER_FAILED');

				

			}

		}

		else

		{

			$responseMsg="Security Error ..!";

			$status=Configuration::get('ZAAKPAY_ID_ORDER_FAILED');

		}

		

				



		



		$cart = new Cart(intval($order_id));

		



		$this->validateOrder($order_id, $status, (float)$cart->getOrderTotal(true,Cart::BOTH), $responseMsg,  $this->displayName, array('response_code' =>$res_code, 'response_description' => $res_desc));

			

		$smarty->assign(array('this_path' => $this->_path,

					'responseMsg'	=> $responseMsg,

					'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://').htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/'.$this->name.'/'

					));

		

    }

	

	/*public function validateOrder($id_cart, $id_order_state, $amountPaid, $paymentMethod = 'Unknown', 

		$message = NULL, $extraVars = array(), $currency_special = NULL, $dont_touch_amount = false)

	{

		if (!$this->active)

			return ;



		$currency = $this->getCurrency();

		$cart = new Cart(intval($id_cart));

		$cart->id_currency = $currency->id;

		$cart->save();

		parent::validateOrder($id_cart, $id_order_state, $amountPaid, $paymentMethod, $message, $extraVars, $currency_special, true);

	}*/



}

?>

