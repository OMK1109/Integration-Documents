<?php
/**
 * Zaakpay payment module response page
 *

 * 
 */


/* SSL Management */
//$useSSL = true;

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/Zaakpay.php');

$order_id = $_POST['orderId'];
$res_code = $_POST['responseCode'];
$res_desc = $_POST['responseDescription'];
$res_amt = $_POST['amount'];
$res_pm = $_POST['paymentMethod'];
$res_cid = $_POST['cardhashid'];
$checksum_recv = $_POST['checksum'];
$all = ("'". $order_id ."''". $res_code ."''". $res_desc."''".$res_amt."''".$res_pm."''".$res_cid."'");
error_log("order id = {$order_id} , resp code = {$res_code} , resp desciption = {$res_desc} , checksum = {$checksum_recv}");
$obj=new Zaakpay();
$obj->setOrder($order_id,$res_code,$res_desc,$checksum_recv,$all);

$smarty->display(dirname(__FILE__).'/response.tpl');

include(dirname(__FILE__).'/../../footer.php');	

?>
