PAYMENT MODULE : ZAAKPAY
---------------------------
Allows you to use Zaakpay payment gateway with Prestashop.
	
	
CONFIGURATION
-----------------

-	Login to the administrator area of Prestashop ,
-	Goto the modules tab and upload the Zaakpay module ,
-	Once it gets installed properly , you can see Zaakpay in the Module list . If you do not see Zaakpay in the list make sure the module is installed properly without any bug.
-	Click Configure from the Zaakpay module and Enter your own Merchant Id and Secret Key provided by Zaakpay and select the Mode you want to work on.
-  	At the Log option, Select Off if you don want to log params into the error_log file. 
-	Click update/save.

Now you can make your payment securely through Zaakpay by selecting Zaakpay as the Payment Method at the Checkout stage.

