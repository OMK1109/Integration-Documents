MODULE NAME  :  ZAAKPAY GATEWAY MODULE FOR WHMCS
--------------------------------------------------

INSTALLATION PROCEDURE
------------------------
-	Extract the downloaded Zip file
-	There are total two files called zaakpay.php and response.php
-	After the installation of WHMCS, just copy the zaakpay.php file into whmcs(root)/modules/gateways folder
-	Copy the file response.php into whmcs(root)/modules/gateways/callback folder


CONFIGUARTION
---------------
-	Login to the admininstrator area of WHMCS, under Setup tab click Payment Gateways
-	In the Activate Module drop down list select Zaakpay and click Activate
-	A panel appears in tha Zaakpay, Enter the Merchant Id, Secret Key provided by Zaakpay and the mode you need to do your transaction
-	Then click Save changes

You can now see Zaakpay at the Payment Method list in the client area. You can now pay through Zaakpay Payment Gateway.

