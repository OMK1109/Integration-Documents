
PAYMENT MODULE : ZAAKPAY
---------------------------
Allows you to use Zaakpay payment gateway with Zencart.

INSTALLATION PROCEDURE
--------------------------

-	Ensure you have latest version of Zencart installed ,
-	Extract the downloaded zip file , there are two folders called languages and modules ,
-	Copy the file present in the language folder and paste it to zencart(root)\includes\languages\english\modules\payment,
-	Copy the file present in the modules folder and paste it to zencart(root)\includes\modules\payment.

CONFIGURATION
-----------------

-	Login to the administrator area of Zencart ,
-	Choose Modules -> Payment , you can see Zaakpay under the Payment Modules list ,
-	Click on the action tab and install it . If you do not see Zaakpay in the list make sure you have copied the file properly, 
-	Once it get installed , Enter your own Merchant Id and Secret Key provided by Zaakpay and select the Mode you want to work on,
-	Click update/save .


Now you can make your payment securely through Zaakpay by selecting Zaakpay as the Payment Method at the Checkout stage.

